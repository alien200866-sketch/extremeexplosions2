import json, os, zipfile, sys
ROOT='/home/claude/ee2/horizon/ee2-horizon'; ID='extremeexplosions2'; VER='1.1.0'
OUT=f'/home/claude/ee2/horizon/dist/{ID}-26.3-{VER}.hmod'
native={"schema":1,"id":ID,"version":VER,"game":"26.3",
 "horizon":"9f42064c11efe7ef3e5ed2baad7ddc2a3b36eea0",
 "mixins":"5a64af938ec86b00d53d16a408aabc0038fb3e57"}
files={}
files['horizon-mod.toml']=open(f'{ROOT}/horizon-mod.toml','rb').read()
files['horizon-native.json']=(json.dumps(native,indent=2)+'\n').encode()
for top in ('assets','data','mixins'):
    for d,_,fs in os.walk(f'{ROOT}/{top}'):
        for f in fs:
            p=os.path.join(d,f); rel=os.path.relpath(p,ROOT).replace(os.sep,'/')
            if '/target/' in rel: continue
            files[rel]=open(p,'rb').read()
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED) as z:
    for name in sorted(files):
        info=zipfile.ZipInfo(name,(2026,11,17,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o644<<16
        z.writestr(info,files[name])
print(OUT,len(files),'files',os.path.getsize(OUT),'bytes')
