"""Particles for Extreme Explosions 2 on Horizon (Polytone custom particle types).

Each fx_* type is a port of the Java mod's FxParticle: size, colour and alpha curves, drag, rise,
gravity and spin, all set per particle by the code that spawns it (a Polytone seed), or for the
fuse_* types (which the server sends) by their initializer.
"""
import json, os, random, shutil
from PIL import Image
SRC='/home/claude/ee2/src263/src/main/resources/assets/extremeexplosions2/textures/particle'
OUT='/home/claude/ee2/horizon/ee2-horizon/assets/extremeexplosions2'
TEX=OUT+'/textures/particle'; SETS=OUT+'/particles'; POLY=OUT+'/polytone/custom_particles'
for d in (TEX,SETS,POLY):
    shutil.rmtree(d,ignore_errors=True); os.makedirs(d)
# the Java mod's white masks, tinted per particle
for f in os.listdir(SRC):
    if f.endswith('.png'): shutil.copy(f'{SRC}/{f}',f'{TEX}/{f}')
# chunky bits of rock for flying debris (grey, tinted by the ground's colour)
rnd=random.Random(7)
for k in range(4):
    im=Image.new('RGBA',(8,8),(0,0,0,0)); px=im.load()
    cx,cy=3.5+rnd.uniform(-.5,.5),3.5+rnd.uniform(-.5,.5)
    for y in range(8):
        for x in range(8):
            d=((x-cx)**2+(y-cy)**2)**.5
            if d < 3.2+rnd.uniform(-.9,.4):
                v=int(150+rnd.uniform(-45,60)); px[x,y]=(v,v,v,255)
    im.save(f'{TEX}/debris_{k}.png')
def sprites(name,tex):
    json.dump({"textures":[f'extremeexplosions2:{t}' for t in tex]},open(f'{SETS}/{name}.json','w'),indent=1)
FIRE=['fire_0','fire_1','fire_2','fire_3']; SMOKE=['smoke_0','smoke_1','smoke_2','smoke_3']
TICKER={
 "dy":"o.yd + o.custom('rise') - o.custom('grav')",
 "red":"lerp(o.custom('r0'), o.custom('r1'), clamp(o.age / o.life, 0, 1))",
 "green":"lerp(o.custom('g0'), o.custom('g1'), clamp(o.age / o.life, 0, 1))",
 "blue":"lerp(o.custom('b0'), o.custom('b1'), clamp(o.age / o.life, 0, 1))",
 "alpha":"t = clamp(o.age / o.life, 0, 1); fi = o.custom('fi'); fo = o.custom('fo'); a0 = o.custom('a0'); a1 = (fi > 0 && t < fi) ? a0 * t / fi : a0; a2 = t > fo ? a1 * (1 - (t - fo) / (1 - fo)) : a1; clamp(a2, 0, 1)",
 "size":"t = clamp(o.age / o.life, 0, 1); e = 1 - pow(1 - t, 1 / max(0.15, o.custom('ease'))); lerp(o.custom('s0'), o.custom('s1'), e)",
 "roll":"o.roll + o.custom('spin')",
}
# a bolt: steady size and colour, flickering like lightning (or a steady glow for magma cracks)
BOLT_TICKER={
 "alpha":"t = clamp(o.age / o.life, 0, 1); s = o.custom('seed'); a = o.custom('a0'); f = o.custom('steady') > 0 ? (t < 0.1 ? t / 0.1 : 1 - (t - 0.1) / 0.9) * (0.85 + 0.15 * sin(o.age * 0.9 + s)) : (1 - t * t) * ((o.age >= 2 && mod(o.age + s, 3) == 0) ? 0.2 : 1); clamp(a * f, 0, 1)",
}
def ptype(name,tex,additive,ticker=TICKER,init=None,physics=False,light=None):
    sprites(name,tex)
    d={"render_type":"additive_translucent" if additive else "translucent",
       "has_physics":physics,"kill_when_still":False,"kill_when_not_in_view":False,
       "random_sprite":True,"light_level":15 if additive else (light or 5),
       "ticker":ticker}
    if init: d["initializer"]=init
    json.dump(d,open(f'{POLY}/{name}.json','w'),indent=1)
ptype('fx_fire',FIRE,True)
ptype('fx_flash',['flash'],True)
ptype('fx_spark',['spark'],True)
ptype('fx_smoke',SMOKE,False)
ptype('fx_bolt',['flash'],True,ticker=BOLT_TICKER)
ptype('fx_debris',[f'debris_{k}' for k in range(4)],False,physics=True,light=4)
# the lit fuse's particles, sent by the server: everything set by their initializer
THEMES={'orange':((1.0,0.92,0.55),(1.0,0.35,0.06)),'red':((1.0,0.45,0.25),(0.85,0.05,0.0)),'blue':((1.0,1.0,0.85),(0.55,0.8,1.0))}
def fuse(name,tex,life,size,s1,a0,fo,friction,grav,theme):
    c0,c1=THEMES[theme]
    init={"lifetime":life,"size":size,"friction":str(friction),"roll":"r.rand(6.283)",
          "red":str(c0[0]),"green":str(c0[1]),"blue":str(c0[2]),"alpha":str(a0)}
    init["customs"]={"s0":"o.size","s1":str(s1),"ease":"0.5","r0":str(c0[0]),"g0":str(c0[1]),"b0":str(c0[2]),
          "r1":str(c1[0]),"g1":str(c1[1]),"b1":str(c1[2]),"a0":str(a0),"fi":"0","fo":str(fo),
          "rise":"0","grav":str(grav),"spin":"0"}
    ptype(name,tex,True,init=init)
for th in THEMES:
    fuse(f'fuse_tip_{th}',['flash'],"3","0.24","0.1",0.85,0.0,1.0,0.0,th)
    fuse(f'fuse_spark_{th}',['spark'],"8 + floor(r.rand(10))","0.035 + r.rand(0.03)","0.01",1.0,0.5,0.96,0.035,th)
    fuse(f'fuse_crackle_{th}',['spark'],"5 + floor(r.rand(6))","0.03 + r.rand(0.025)","0.008",1.0,0.4,0.92,0.03,th)
    fuse(f'fuse_flash_{th}',['flash'],"2","0.25","0.1",0.7,0.0,1.0,0.0,th)
print(len(os.listdir(POLY)),'particle types,',len(os.listdir(TEX)),'textures')
