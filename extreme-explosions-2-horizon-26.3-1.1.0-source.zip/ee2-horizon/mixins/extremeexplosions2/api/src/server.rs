//! The server half: lighting the TNT, the lit fuse, chain reactions, the craters, the extra damage
//! and the deeper booms.
//!
//! Lit TNT of this mod is not the game's primed TNT, whose look (plain TNT flashing white) the
//! game draws itself. It is a block display of the TNT's own block that rattles and rocks more
//! and more violently as its fuse burns down, with a fizzing fuse on top spitting sparks. When the
//! fuse runs out the display goes and a primed TNT with this generation's power takes its place
//! with no fuse left, so it goes off that same tick.
use crate::Rng;
use crate::crater::Crater;
use crate::gens::{self, Gen};
use horizon_client::mod_api::*;
use std::collections::HashMap;

/// `Level.setBlock` flags: neighbours told, clients told.
const UPDATE_ALL: i32 = 3;
/// Sound sources (`SoundSource` ordinals).
const BLOCKS: usize = 4;
const WEATHER: usize = 3;

/// Lit TNT to put into the world on the next tick of its level.
struct Prime {
    dimension: String,
    pos: [i32; 3],
    /// 1 is plain vanilla TNT (a crater lighting it).
    tg: u8,
    /// Set off by a blast: a short random fuse, as vanilla's `wasExploded`.
    short: bool,
    /// Play the lighting fizz (the game already played it for TNT it lit itself).
    sound: bool,
}

/// Extra damage a blast does on the next tick of its level (`BlastDamage`).
struct Blast {
    dimension: String,
    center: [f64; 3],
    tg: u8,
}

/// Lit TNT of the mod: its block display and what is left of its fuse.
struct Fuse {
    dimension: String,
    pos: [i32; 3],
    tg: u8,
    display: u32,
    left: i32,
    age: i32,
}

#[derive(Default)]
pub struct Server {
    /// Every block state of the mod's TNT blocks, with its generation.
    states: Option<HashMap<u32, u8>>,
    air: Option<BlockStateId>,
    tick: u64,
    /// The mod's TNT blocks the game took out this tick (fire, redstone, a burning arrow):
    /// where the plain primed TNT the game makes for them will appear.
    removed: HashMap<(String, [i32; 3]), (u8, u64)>,
    primes: Vec<Prime>,
    /// The mod's primed TNT by entity id: its level and generation.
    lit: HashMap<u32, (String, u8)>,
    fuses: Vec<Fuse>,
    craters: Vec<Crater>,
    blasts: Vec<Blast>,
    rng: Rng,
}

fn floor(v: [f64; 3]) -> [i32; 3] {
    [
        v[0].floor() as i32,
        v[1].floor() as i32,
        v[2].floor() as i32,
    ]
}

impl Server {
    /// Resolves the mod's block states once the game can name them.
    fn init(&mut self, host: &dyn Host) {
        if self.states.is_some() {
            return;
        }
        let mut states = HashMap::new();
        for g in &gens::GENS[1..] {
            let Some(default) = host.default_state(&g.block()) else {
                continue;
            };
            states.insert(default.0, g.number);
            // TNT has one property, `unstable`, listed true first as vanilla lists booleans.
            for other in [default.0.wrapping_sub(1), default.0 + 1] {
                if host.block_state_property(BlockStateId(other), "unstable") == Some("true")
                    && !states.contains_key(&other)
                {
                    states.insert(other, g.number);
                    break;
                }
            }
        }
        self.air = host.default_state("minecraft:air");
        self.states = Some(states);
    }

    pub fn block_changed(&mut self, event: &BlockChangedEvent) {
        let Some(states) = &self.states else {
            return;
        };
        let Some(&tg) = states.get(&event.old.0) else {
            return;
        };
        if states.contains_key(&event.new.0) {
            return; // only its `unstable` flag changed
        }
        let pos = [event.pos.x, event.pos.y, event.pos.z];
        let dim = event.dimension.key().id().to_owned();
        self.removed.insert((dim, pos), (tg, self.tick));
    }

    /// A primed TNT joins a level. One the game made for the mod's block is kept out, and the
    /// mod's own takes its place.
    pub fn tnt_joined(&mut self, host: &mut dyn Host, event: &EntityJoinLevelEvent<'_>) -> Flow {
        if event.kind == "minecraft:block_display" {
            // A lit TNT saved with its world: light it again with a short fuse.
            if event.loaded_from_disk
                && let Some(entity) = host.entity(event.entity)
                && let Some(tg) = host
                    .entity_tags(entity)
                    .and_then(|t| gens::gen_of_fuse_tags(&t))
                && !self.fuses.iter().any(|f| f.display == event.entity)
            {
                self.fuses.push(Fuse {
                    dimension: event.dimension.to_owned(),
                    pos: floor(event.pos),
                    tg,
                    display: event.entity,
                    left: 40,
                    age: 0,
                });
            }
            return Flow::Continue;
        }
        if event.loaded_from_disk {
            // Back with its chunk: remember it for its fuse sparks.
            if let Some(entity) = host.entity(event.entity)
                && let Some(tg) = host.entity_tags(entity).and_then(|t| gens::gen_of_tags(&t))
            {
                self.lit
                    .insert(event.entity, (event.dimension.to_owned(), tg));
            }
            return Flow::Continue;
        }
        let pos = floor(event.pos);
        let Some((tg, _)) = self.removed.remove(&(event.dimension.to_owned(), pos)) else {
            return Flow::Continue;
        };
        self.primes.push(Prime {
            dimension: event.dimension.to_owned(),
            pos,
            tg,
            short: false,
            sound: false,
        });
        Flow::Cancel
    }

    /// Flint and steel or a fire charge on the mod's TNT (vanilla only lights its own).
    pub fn light_by_hand(
        &mut self,
        host: &mut dyn Host,
        pos: [i32; 3],
        tg: u8,
        charge: bool,
    ) -> Flow {
        self.init(host);
        let Some(player) = host.acting_player() else {
            return Flow::Continue;
        };
        let Some(air) = self.air else {
            return Flow::Continue;
        };
        host.set_block(&player.dimension, pos, air, UPDATE_ALL);
        if charge && player.game_mode != 1 {
            host.take_items("minecraft:fire_charge", 1);
        }
        self.primes.push(Prime {
            dimension: player.dimension,
            pos,
            tg,
            short: false,
            sound: true,
        });
        Flow::Cancel
    }

    pub fn detonate(&mut self, host: &mut dyn Host, event: &mut ExplosionDetonateEvent<'_>) {
        self.init(host);
        let dim = event.dimension.to_owned();
        // Which generation went off: one the mod lit, or one saved with its tag.
        let mut tg = 1;
        if let Some((id, kind)) = event.source
            && kind == "minecraft:tnt"
        {
            if let Some((_, g)) = self.lit.remove(&id) {
                tg = g;
            } else if let Some(entity) = host.entity(id)
                && let Some(g) = host.entity_tags(entity).and_then(|t| gens::gen_of_tags(&t))
            {
                tg = g;
            }
        }
        let g = *Gen::of(tg);

        // Chain reactions: the mod's TNT in reach is lit with a short fuse, not left to the game,
        // which would light it as plain TNT.
        let air = self.air;
        event.blocks.retain(|&pos| {
            let Some(n) = gens::gen_of_block(&host.block(pos)) else {
                return true;
            };
            if let Some(air) = air {
                host.set_block(&dim, pos, air, UPDATE_ALL);
            }
            self.primes.push(Prime {
                dimension: dim.clone(),
                pos,
                tg: n,
                short: true,
                sound: false,
            });
            false
        });
        if tg < 2 {
            return;
        }
        let c = event.center;
        if g.carves() {
            // The crater is carved separately, spreading out from the middle.
            event.blocks.clear();
            let underwater = host.block(floor(c)) == "minecraft:water";
            if !underwater {
                let seed = self.rng.next_u64();
                self.craters.push(Crater::new(dim.clone(), c, g, seed));
            }
        }
        self.blasts.push(Blast {
            dimension: dim,
            center: c,
            tg,
        });
        // Extra, deeper booms that carry further than vanilla's.
        let pitch = (0.95 - tg as f32 * 0.05).max(0.5);
        host.play_sound(
            "minecraft:entity.generic.explode",
            c,
            BLOCKS,
            4.0 + tg as f32 * 1.5,
            pitch,
        );
        if tg >= 8 {
            host.play_sound(
                "minecraft:entity.lightning_bolt.thunder",
                c,
                WEATHER,
                6.0 + tg as f32,
                0.5,
            );
        }
    }

    pub fn level_tick(&mut self, host: &mut dyn Host, dimension: &str) {
        self.init(host);
        self.tick += 1;
        let tick = self.tick;
        self.removed.retain(|_, (_, at)| tick - *at < 5);

        // Light the TNT waiting for this level.
        let mut i = 0;
        while i < self.primes.len() {
            if self.primes[i].dimension != dimension {
                i += 1;
                continue;
            }
            let p = self.primes.swap_remove(i);
            self.summon(host, p);
        }

        // Burn the fuses down.
        let mut i = 0;
        while i < self.fuses.len() {
            if self.fuses[i].dimension != dimension {
                i += 1;
                continue;
            }
            let f = &mut self.fuses[i];
            f.left -= 1;
            f.age += 1;
            if f.left > 0 {
                fuse_tick(host, &self.fuses[i], &mut self.rng);
                i += 1;
                continue;
            }
            let f = self.fuses.swap_remove(i);
            host.remove_entity(&f.dimension, f.display);
            self.detonate_fuse(host, &f);
        }

        // Extra damage from last tick's blasts.
        let mut i = 0;
        while i < self.blasts.len() {
            if self.blasts[i].dimension != dimension {
                i += 1;
                continue;
            }
            let b = self.blasts.swap_remove(i);
            blast_damage(host, &b);
        }

        // Carve the craters, sharing one budget of blocks a tick.
        let mut budget = 6000;
        let mut lit = Vec::new();
        for crater in self.craters.iter_mut().filter(|c| c.dimension == dimension) {
            budget = crater.step(host, budget, self.air, &mut lit);
        }
        self.craters.retain(|c| !c.finished);
        for (pos, tg) in lit {
            self.primes.push(Prime {
                dimension: dimension.to_owned(),
                pos,
                tg,
                short: true,
                sound: false,
            });
        }
    }

    /// Lights `p`: plain TNT (a crater lighting it) becomes the game's primed TNT; the mod's own
    /// becomes a lit fuse, a block display of its block.
    fn summon(&mut self, host: &mut dyn Host, p: Prime) {
        let g = *Gen::of(p.tg);
        let fuse = if p.short {
            g.fuse / 8 + self.rng.below(g.fuse / 4)
        } else {
            g.fuse
        };
        let at = [
            p.pos[0] as f64 + 0.5,
            p.pos[1] as f64,
            p.pos[2] as f64 + 0.5,
        ];
        if p.sound {
            // Deeper and deeper fizz for the bigger generations.
            let pitch = 1.0 - (p.tg.max(1) as f32 - 1.0) * 0.04;
            host.play_sound("minecraft:entity.tnt.primed", at, BLOCKS, 1.0, pitch);
        }
        if p.tg < 2 {
            let a = self.rng.f() * std::f64::consts::TAU;
            let snbt = format!(
                "{{fuse:{fuse}s,Motion:[{mx}d,0.2d,{mz}d]}}",
                mx = -a.sin() * 0.02,
                mz = -a.cos() * 0.02,
            );
            if let Ok((Tag::Compound(nbt), _)) = parse_snbt(&snbt) {
                host.summon(&p.dimension, "minecraft:tnt", at, nbt);
            }
            return;
        }
        // The display stands on the block's bottom middle, its block moved back half a block, so
        // turning it rocks the block about its base.
        let snbt = format!(
            "{{block_state:{{Name:\"{block}\"}},teleport_duration:1,\
             transformation:{{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],\
             translation:[-0.5f,0f,-0.5f],scale:[1f,1f,1f]}},Tags:[\"{tag}\"]}}",
            block = g.block(),
            tag = gens::fuse_tag(p.tg),
        );
        let Ok((Tag::Compound(nbt), _)) = parse_snbt(&snbt) else {
            return;
        };
        let Some(display) = host.summon(&p.dimension, "minecraft:block_display", at, nbt) else {
            // No display (the game refused it): fall back to the game's primed TNT.
            self.go_off(host, &p.dimension, at, p.tg, fuse);
            return;
        };
        self.fuses.push(Fuse {
            dimension: p.dimension,
            pos: p.pos,
            tg: p.tg,
            display,
            left: fuse,
            age: 0,
        });
    }

    fn detonate_fuse(&mut self, host: &mut dyn Host, f: &Fuse) {
        let at = [
            f.pos[0] as f64 + 0.5,
            f.pos[1] as f64,
            f.pos[2] as f64 + 0.5,
        ];
        self.go_off(host, &f.dimension, at, f.tg, 0);
    }

    /// A primed TNT with generation `tg`'s power and tag; with no fuse left it goes off on the
    /// tick it joins.
    fn go_off(&mut self, host: &mut dyn Host, dimension: &str, at: [f64; 3], tg: u8, fuse: i32) {
        let g = *Gen::of(tg);
        let snbt = format!(
            "{{fuse:{fuse}s,explosion_power:{power}f,block_state:{{Name:\"{block}\"}},Tags:[\"{tag}\"]}}",
            power = g.power(),
            block = g.block(),
            tag = g.tag(),
        );
        let Ok((Tag::Compound(nbt), _)) = parse_snbt(&snbt) else {
            return;
        };
        if let Some(id) = host.summon(dimension, "minecraft:tnt", at, nbt) {
            self.lit.insert(id, (dimension.to_owned(), tg));
        }
    }
}

/// One tick of a lit fuse (`GenTntRenderer` and `FuseEffects`): the block rattles, hops and
/// rocks, gently at first and more and more violently over the last four seconds, while the
/// fuse on top fizzes and spits a fountain of sparks and crackles jump off its sides.
fn fuse_tick(host: &mut dyn Host, f: &Fuse, r: &mut Rng) {
    let base = [
        f.pos[0] as f64 + 0.5,
        f.pos[1] as f64,
        f.pos[2] as f64 + 0.5,
    ];
    let left = ((f.left - 1) as f64 / 80.0).clamp(0.0, 1.0);
    let anger = 1.0 - left;
    let amp = (0.012 + 0.07 * anger * anger) * (1.0 + (f.tg as f64 - 1.0) * 0.06);
    let t = f.age as f64 + (f.display % 97) as f64 * 13.7;
    let dx = ((t * 7.3).sin() + (t * 17.9 + 1.3).sin() * 0.6) * amp;
    let dy = ((t * 9.1 + 2.1).sin() + (t * 21.7).sin()) * amp * 0.45;
    let dz = ((t * 8.2 + 4.0).sin() + (t * 15.3 + 0.7).sin() * 0.6) * amp;
    let tilt = amp * 55.0;
    host.move_entity(
        &f.dimension,
        f.display,
        [base[0] + dx, base[1] + dy.abs(), base[2] + dz],
        ((t * 5.9).sin() * tilt * 0.6) as f32,
        ((t * 11.3 + 0.5).sin() * tilt) as f32,
    );

    let theme = match f.tg {
        9 => "red",
        10 => "blue",
        _ => "orange",
    };
    let tip = [base[0], base[1] + 1.05, base[2]];
    // The glowing fuse tip.
    let tip_kind = format!("extremeexplosions2:fuse_tip_{theme}");
    host.send_particles(
        &ParticleOptions::named(tip_kind),
        None,
        tip,
        [0.0; 3],
        0.0,
        1,
    );
    // A fountain of sparks from the fuse.
    let spark = format!("extremeexplosions2:fuse_spark_{theme}");
    let n = (1.0 + anger * 4.0) as i32 + i32::from(f.tg >= 6);
    for _ in 0..n {
        let v = [
            (r.f() - 0.5) * (0.12 + anger * 0.1),
            0.12 + r.f() * (0.18 + anger * 0.12),
            (r.f() - 0.5) * (0.12 + anger * 0.1),
        ];
        host.send_particles(&ParticleOptions::named(spark.clone()), None, tip, v, 1.0, 0);
    }
    // Crackles jumping off the sides, more and more often near the end.
    if r.f() < 0.08 + anger * 0.7 {
        let face = r.below(4);
        let fx = match face {
            0 => 0.51,
            1 => -0.51,
            _ => r.f() - 0.5,
        };
        let fz = match face {
            2 => 0.51,
            3 => -0.51,
            _ => r.f() - 0.5,
        };
        let at = [base[0] + fx, base[1] + 0.15 + r.f() * 0.8, base[2] + fz];
        let crackle = format!("extremeexplosions2:fuse_crackle_{theme}");
        for _ in 0..2 + r.below(3 + (anger * 5.0) as i32) {
            let out = 0.06 + r.f() * 0.12;
            let v = [
                match face {
                    0 => out,
                    1 => -out,
                    _ => 0.0,
                } + (r.f() - 0.5) * 0.08,
                0.04 + r.f() * 0.1,
                match face {
                    2 => out,
                    3 => -out,
                    _ => 0.0,
                } + (r.f() - 0.5) * 0.08,
            ];
            host.send_particles(
                &ParticleOptions::named(crackle.clone()),
                None,
                at,
                v,
                1.0,
                0,
            );
        }
        let flash = format!("extremeexplosions2:fuse_flash_{theme}");
        host.send_particles(&ParticleOptions::named(flash), None, at, [0.0; 3], 0.0, 1);
    }
}

/// Makes sure big TNT actually kills what it hits (`BlastDamage`). Vanilla's damage is scaled by
/// how much of a mob the blast can see, so walls shelter mobs from blasts whose craters come a
/// moment later. Gens II-V: walls only soften the blast. Gens VI-X: inside the crater is
/// obliterated, just outside the rim is hit hard and thrown. Hurting a mob again within its
/// hurt time only adds what is above the earlier hit, so vanilla's own damage is not doubled.
fn blast_damage(host: &mut dyn Host, b: &Blast) {
    let g = *Gen::of(b.tg);
    let c = b.center;
    if g.carves() {
        let r = g.crater_radius() as f64;
        let outer = r * 1.6;
        let lethal = 60.0 + b.tg as f32 * 15.0;
        let min = [c[0] - outer, c[1] - g.down as f64 - 2.0, c[2] - outer];
        let max = [c[0] + outer, c[1] + g.up as f64 + 3.0, c[2] + outer];
        for id in host.entities_in(&b.dimension, min, max) {
            let Some(e) = host.entity(id) else { continue };
            let Some(at) = host.entity_position(e) else {
                continue;
            };
            let (dx, dz) = (at[0] - c[0], at[2] - c[2]);
            let h = (dx * dx + dz * dz).sqrt() / r;
            if h > 1.6 {
                continue;
            }
            let inside = h <= 1.0;
            let damage = if inside {
                lethal * (1.0 - h as f32 * 0.4)
            } else {
                lethal * 0.35 * (1.0 - (h as f32 - 1.0) / 0.6)
            };
            host.hurt_entity(&b.dimension, id, damage, "minecraft:explosion", None);
            // Thrown outward and upward (a player's own client moves them).
            let push = (if inside { 2.2 } else { 1.2 }) * (1.0 - (h / 1.6).min(1.0)) + 0.3;
            let len = (dx * dx + dz * dz).sqrt();
            let (nx, nz) = if len < 0.01 {
                (0.0, 0.0)
            } else {
                (dx / len, dz / len)
            };
            if let Some(e) = host.entity(id) {
                host.entity_push(e, [nx * push, 0.35 + push * 0.45, nz * push]);
            }
        }
    } else {
        let reach = g.base_power as f64 * 2.0;
        let min = [c[0] - reach - 1.0, c[1] - reach - 1.0, c[2] - reach - 1.0];
        let max = [c[0] + reach + 1.0, c[1] + reach + 1.0, c[2] + reach + 1.0];
        for id in host.entities_in(&b.dimension, min, max) {
            let Some(e) = host.entity(id) else { continue };
            let Some(at) = host.entity_position(e) else {
                continue;
            };
            let d = ((at[0] - c[0]).powi(2) + (at[1] - c[1]).powi(2) + (at[2] - c[2]).powi(2))
                .sqrt()
                / reach;
            if d > 1.0 {
                continue;
            }
            // A wall takes at most half of the blast away.
            let impact = (1.0 - d) * 0.5;
            let damage = ((impact * impact + impact) / 2.0 * 7.0 * reach + 1.0) as f32;
            host.hurt_entity(&b.dimension, id, damage, "minecraft:explosion", None);
        }
    }
}
