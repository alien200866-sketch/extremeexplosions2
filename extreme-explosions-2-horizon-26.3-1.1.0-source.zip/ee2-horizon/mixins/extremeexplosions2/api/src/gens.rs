//! The ten generations of TNT and how big each one is. Gen I is plain vanilla TNT (only its
//! effect is replaced); Gens II-V use a stronger vanilla explosion; Gens VI-X carve their own
//! crater.
use horizon_client::mod_api::Text;

#[derive(Clone, Copy, Debug)]
pub struct Gen {
    pub number: u8,
    /// Vanilla explosion strength. For Gens VI+ it only decides how far mobs and players get
    /// hurt: the crater is carved separately.
    pub base_power: f32,
    /// Total crater width in blocks (0 = vanilla shaped explosion).
    pub width: i32,
    pub down: i32,
    pub up: i32,
    pub fuse: i32,
    /// Size of the explosion effects.
    pub effect_radius: f32,
}

const fn tg(n: u8, power: f32, width: i32, down: i32, up: i32, fuse: i32, effect: f32) -> Gen {
    Gen {
        number: n,
        base_power: power,
        width,
        down,
        up,
        fuse,
        effect_radius: effect,
    }
}

pub const GENS: [Gen; 10] = [
    //  tg power  width down up fuse effect
    tg(1, 4.0, 0, 0, 0, 80, 4.0),
    tg(2, 5.5, 0, 0, 0, 80, 5.5),
    tg(3, 7.0, 0, 0, 0, 90, 7.0),
    tg(4, 8.5, 0, 0, 0, 100, 8.5),
    tg(5, 10.0, 0, 0, 0, 110, 10.0),
    tg(6, 5.0, 20, 5, 5, 120, 12.0),
    tg(7, 6.25, 25, 10, 10, 130, 14.0),
    tg(8, 7.5, 30, 10, 15, 140, 16.5),
    tg(9, 10.0, 40, 15, 15, 150, 20.0),
    tg(10, 12.5, 50, 20, 20, 160, 25.0),
];

impl Gen {
    pub fn of(n: u8) -> &'static Gen {
        &GENS[(n.clamp(1, 10) - 1) as usize]
    }
    pub fn carves(&self) -> bool {
        self.width > 0
    }
    pub fn crater_radius(&self) -> f32 {
        self.width as f32 / 2.0
    }
    /// The explosion power the primed TNT carries: the base power plus a two-thousandth per
    /// generation, too little to change the blast but enough for every client to tell the
    /// generation from the explosion packet's radius.
    pub fn power(&self) -> f32 {
        if self.number < 2 {
            self.base_power
        } else {
            self.base_power + 0.002 * self.number as f32
        }
    }
    /// The block's id.
    pub fn block(&self) -> String {
        format!("extremeexplosions2:tnt_gen_{}", self.number)
    }
    pub fn tag(&self) -> String {
        format!("ee2_gen_{}", self.number)
    }
}

/// The generation an explosion of `radius` came from: II to X for this mod's TNT, else none.
pub fn gen_of_radius(radius: f32) -> Option<u8> {
    GENS[1..]
        .iter()
        .find(|g| (g.power() - radius).abs() < 0.0006)
        .map(|g| g.number)
}

/// The generation of a block or item id (`extremeexplosions2:tnt_gen_7` is 7).
pub fn gen_of_block(id: &str) -> Option<u8> {
    let n: u8 = id
        .strip_prefix("extremeexplosions2:tnt_gen_")?
        .parse()
        .ok()?;
    (2..=10).contains(&n).then_some(n)
}

/// The tag of a lit fuse's block display (`ee2_fuse_7`).
pub fn fuse_tag(n: u8) -> String {
    format!("ee2_fuse_{n}")
}

/// The generation a lit fuse's display tag names (`ee2_fuse_7`).
pub fn gen_of_fuse_tags(tags: &[String]) -> Option<u8> {
    tags.iter().find_map(|t| {
        let n: u8 = t.strip_prefix("ee2_fuse_")?.parse().ok()?;
        (2..=10).contains(&n).then_some(n)
    })
}

/// The generation an entity tag names (`ee2_gen_7`).
pub fn gen_of_tags(tags: &[String]) -> Option<u8> {
    tags.iter().find_map(|t| {
        let n: u8 = t.strip_prefix("ee2_gen_")?.parse().ok()?;
        (2..=10).contains(&n).then_some(n)
    })
}

// Tooltip colours, as `rgba` packs them (red in the low byte).
const GRAY: u32 = 0xFFAA_AAAA;
const DARK_GRAY: u32 = 0xFF55_5555;
const GOLD: u32 = 0xFF00_AAFF;

pub fn tooltip(n: u8, lines: &mut Vec<(Text, u32)>) {
    let g = Gen::of(n);
    let num = |v: i32| Text::literal(v.to_string());
    if g.carves() {
        lines.push((
            Text::translate(
                "tooltip.extremeexplosions2.crater",
                &[num(g.width), num(g.down), num(g.up)],
            ),
            GRAY,
        ));
    } else {
        lines.push((
            Text::translate("tooltip.extremeexplosions2.blast", &[num(n as i32 * 2 + 5)]),
            GRAY,
        ));
    }
    lines.push((
        Text::translate("tooltip.extremeexplosions2.fuse", &[num(g.fuse / 20)]),
        DARK_GRAY,
    ));
    if n == 10 {
        lines.push((
            Text::translate("tooltip.extremeexplosions2.gen_x", &[]),
            GOLD,
        ));
    }
}
