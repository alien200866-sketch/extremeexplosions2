//! Extreme Explosions 2 for Horizon, by AndyMFA. (C) Many Fun Adventures.
//!
//! Nine new generations of TNT (Gen II to Gen X). Gens II-V make a bigger vanilla blast; Gens
//! VI-X carve their own crater, spreading out from the middle over about a second. Every
//! explosion the player sees, vanilla TNT and creepers too, gets the big fireball, smoke,
//! sparks, dust ring, camera shake and, for the biggest, a shockwave, a screen flash and a wave
//! of energy.
//!
//! How it fits on Horizon: the TNT blocks are content blocks made from `minecraft:tnt`, so the
//! game's own TNT rules light them (redstone, fire, burning arrows). The mod takes the plain
//! primed TNT the game makes for them out of the world and lights its own fuse instead: a block
//! display of the TNT that rattles and rocks, with a fizzing, sparking fuse on top. When the fuse
//! is out, a vanilla primed TNT with this generation's power and an `ee2_gen_N` tag goes off in
//! its place. Each generation's power has a tiny fraction added (`Gen::power`), so a client tells
//! the generation from the explosion packet alone: no networking is needed.
use horizon_client::mod_api::*;
use std::sync::Mutex;

mod client;
mod crater;
mod gens;
mod server;

pub use gens::{GENS, Gen};

pub fn hooks() -> Box<dyn Hooks> {
    Box::new(Ee2 {
        server: Mutex::new(server::Server::default()),
        client: Mutex::new(client::Client::default()),
    })
}

struct Ee2 {
    server: Mutex<server::Server>,
    client: Mutex<client::Client>,
}

/// A tiny xorshift random source, so the mod needs no crates of its own.
pub(crate) struct Rng(u64);

impl Default for Rng {
    fn default() -> Self {
        let seed = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos() as u64)
            .unwrap_or(0x9E37_79B9_7F4A_7C15);
        Self(seed | 1)
    }
}

impl Rng {
    pub(crate) fn next_u64(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.0 = x;
        x
    }
    /// Uniform in 0..1.
    pub(crate) fn f(&mut self) -> f64 {
        (self.next_u64() >> 11) as f64 / (1u64 << 53) as f64
    }
    pub(crate) fn below(&mut self, n: i32) -> i32 {
        if n <= 0 {
            0
        } else {
            (self.next_u64() % n as u64) as i32
        }
    }
    /// A random direction on the unit sphere.
    pub(crate) fn dir(&mut self) -> [f64; 3] {
        let u = self.f() * 2.0 - 1.0;
        let a = self.f() * std::f64::consts::TAU;
        let s = (1.0 - u * u).sqrt();
        [s * a.cos(), u, s * a.sin()]
    }
}

impl Hooks for Ee2 {
    // ---------------- server ----------------

    fn block_changed(&self, _level: &dyn LevelHost, event: &mut BlockChangedEvent) {
        // Only the game's own writes are recorded: while the mod holds its state it is the one
        // writing, and it already knows what it removed.
        if let Ok(mut s) = self.server.try_lock() {
            s.block_changed(event);
        }
    }

    fn entity_join_level(&self, host: &mut dyn Host, event: &mut EntityJoinLevelEvent<'_>) -> Flow {
        if event.kind != "minecraft:tnt" && event.kind != "minecraft:block_display" {
            return Flow::Continue;
        }
        // Held: this is the mod's own summon, which it records itself.
        match self.server.try_lock() {
            Ok(mut s) => s.tnt_joined(host, event),
            Err(_) => Flow::Continue,
        }
    }

    fn use_item_on(&self, host: &mut dyn Host, event: &mut UseItemOnEvent<'_>) -> Flow {
        let item = &*event.stack.item;
        if item != "minecraft:flint_and_steel" && item != "minecraft:fire_charge" {
            return Flow::Continue;
        }
        let Some(tg) = gens::gen_of_block(&host.block(event.pos)) else {
            return Flow::Continue;
        };
        let Ok(mut s) = self.server.lock() else {
            return Flow::Continue;
        };
        s.light_by_hand(host, event.pos, tg, item == "minecraft:fire_charge")
    }

    fn explosion_detonate(&self, host: &mut dyn Host, event: &mut ExplosionDetonateEvent<'_>) {
        if let Ok(mut s) = self.server.lock() {
            s.detonate(host, event);
        }
    }

    fn level_tick_post(&self, host: &mut dyn Host, event: &mut LevelTickPostEvent<'_>) {
        if let Ok(mut s) = self.server.lock() {
            s.level_tick(host, event.dimension);
        }
    }

    // ---------------- client ----------------

    fn client_packet(&self, host: &mut dyn Host, event: &mut ClientPacketEvent<'_>) {
        if let ClientboundPlayPacket::Explode(explode) = event.packet
            && let Ok(mut c) = self.client.lock()
        {
            c.explosion(host, explode.center, explode.radius);
        }
    }

    fn client_tick_post(&self, host: &mut dyn Host, _event: &mut ClientTickPostEvent) {
        if let Ok(mut c) = self.client.lock() {
            c.tick(host);
        }
    }

    fn camera_shake(&self, _host: &dyn Host, event: &mut CameraShakeEvent<'_>) {
        if let Ok(c) = self.client.lock() {
            c.shake(event.shake);
        }
    }

    fn hud(&self, host: &mut dyn Host, event: &mut HudEvent<'_>) {
        if let Ok(c) = self.client.lock() {
            c.flash(host, event.batch);
        }
    }

    fn tooltip(&self, _host: &dyn Host, event: &mut TooltipEvent<'_>) {
        if let Some(tg) = gens::gen_of_block(&event.stack.item) {
            gens::tooltip(tg, event.lines);
        }
    }
}
