//! The client half: the explosion show (`ExplosionDirector`), each big generation's signature
//! effect (`SignatureEffects`), flying burning debris, the camera shake (`ShakeHandler`) and the
//! screen flash (`FlashOverlay`). Every explosion the server sends gets the show: plain TNT,
//! creepers and the rest as Gen I, the mod's TNT by the generation its radius names.
//!
//! The particles are the Java mod's `FxParticle`, as Polytone custom particle types
//! (`assets/extremeexplosions2/polytone/custom_particles/fx_*.json`): each one's sizes, colours,
//! fades and motion are seeded on it here, and its ticker eases them over its life. The fire,
//! flash, sparks and bolts are drawn additive and full bright, as the Java mod drew them.
use crate::Rng;
use crate::gens::{self, Gen};
use horizon_client::mod_api::*;
use horizon_client::particles::polytone::Seed;
use std::collections::BTreeMap;
use std::f64::consts::TAU;
use std::sync::Arc;
use std::time::Instant;

type V3 = [f64; 3];

// ---------------------------------------------------------------- one particle

#[derive(Clone, Copy)]
enum Kind {
    Fire,
    Flash,
    Spark,
    Smoke,
    Debris,
}

impl Kind {
    fn name(self) -> &'static str {
        match self {
            Kind::Fire => "extremeexplosions2:fx_fire",
            Kind::Flash => "extremeexplosions2:fx_flash",
            Kind::Spark => "extremeexplosions2:fx_spark",
            Kind::Smoke => "extremeexplosions2:fx_smoke",
            Kind::Debris => "extremeexplosions2:fx_debris",
        }
    }
}

/// One `FxParticle`: what it looks like over its life and how it moves.
#[derive(Clone, Copy)]
struct Fx {
    kind: Kind,
    life: i32,
    s0: f64,
    s1: f64,
    c0: [f64; 3],
    c1: [f64; 3],
    a0: f64,
    fade_in: f64,
    fade_out: f64,
    drag: f64,
    rise: f64,
    grav: f64,
    spin: f64,
    ease: f64,
}

impl Fx {
    fn new(kind: Kind, life: i32) -> Self {
        Self {
            kind,
            life: life.max(2),
            s0: 0.1,
            s1: 0.1,
            c0: [1.0; 3],
            c1: [1.0; 3],
            a0: 1.0,
            fade_in: 0.0,
            fade_out: 0.5,
            drag: 0.9,
            rise: 0.0,
            grav: 0.0,
            spin: 0.0,
            ease: 0.5,
        }
    }
    fn size(mut self, from: f64, to: f64) -> Self {
        self.s0 = from;
        self.s1 = to;
        self
    }
    fn color(mut self, from: [f64; 3], to: [f64; 3]) -> Self {
        self.c0 = from;
        self.c1 = to;
        self
    }
    fn alpha(mut self, a: f64, fade_in: f64, fade_out: f64) -> Self {
        self.a0 = a;
        self.fade_in = fade_in;
        self.fade_out = fade_out;
        self
    }
    fn motion(mut self, drag: f64, rise: f64, grav: f64) -> Self {
        self.drag = drag;
        self.rise = rise;
        self.grav = grav;
        self
    }
    fn spin(mut self, spin: f64) -> Self {
        self.spin = spin;
        self
    }
    fn ease(mut self, ease: f64) -> Self {
        self.ease = ease;
        self
    }
    fn spawn(&self, host: &mut dyn Host, at: V3, velocity: V3, r: &mut Rng) {
        let fields = BTreeMap::from([
            ("lifetime".to_owned(), self.life as f64),
            ("size".to_owned(), self.s0.min(16.0)),
            ("red".to_owned(), self.c0[0]),
            ("green".to_owned(), self.c0[1]),
            ("blue".to_owned(), self.c0[2]),
            (
                "alpha".to_owned(),
                if self.fade_in > 0.0 { 0.0 } else { self.a0 },
            ),
            ("friction".to_owned(), self.drag),
            ("roll".to_owned(), r.f() * TAU),
        ]);
        let customs = BTreeMap::from([
            ("s0".to_owned(), self.s0.min(16.0)),
            ("s1".to_owned(), self.s1.min(16.0)),
            ("ease".to_owned(), self.ease),
            ("r0".to_owned(), self.c0[0]),
            ("g0".to_owned(), self.c0[1]),
            ("b0".to_owned(), self.c0[2]),
            ("r1".to_owned(), self.c1[0]),
            ("g1".to_owned(), self.c1[1]),
            ("b1".to_owned(), self.c1[2]),
            ("a0".to_owned(), self.a0),
            ("fi".to_owned(), self.fade_in),
            ("fo".to_owned(), self.fade_out),
            ("rise".to_owned(), self.rise),
            ("grav".to_owned(), self.grav),
            ("spin".to_owned(), self.spin),
        ]);
        add(
            host,
            self.kind.name(),
            Seed { fields, customs },
            at,
            velocity,
        );
    }
}

/// Spawns one of the mod's Polytone particles with `seed`. It goes in as an `explosion`
/// particle, which the game shows however far away it is, as the Java mod's own particles were.
fn add(host: &mut dyn Host, name: &str, seed: Seed, at: V3, velocity: V3) {
    let options = ParticleOptions {
        mod_particle: Some(name.to_owned()),
        polytone_seed: Some(Arc::new(seed)),
        ..ParticleOptions::simple(ParticleType::Explosion)
    };
    host.add_particle(&options, at, velocity);
}

fn lerp(t: f64, a: f64, b: f64) -> f64 {
    a + (b - a) * t
}

fn add3(a: V3, b: V3) -> V3 {
    [a[0] + b[0], a[1] + b[1], a[2] + b[2]]
}

fn sub3(a: V3, b: V3) -> V3 {
    [a[0] - b[0], a[1] - b[1], a[2] - b[2]]
}

fn scale3(a: V3, s: f64) -> V3 {
    [a[0] * s, a[1] * s, a[2] * s]
}

fn len3(a: V3) -> f64 {
    (a[0] * a[0] + a[1] * a[1] + a[2] * a[2]).sqrt()
}

fn norm3(a: V3) -> V3 {
    let l = len3(a);
    if l < 1e-9 {
        [0.0, 1.0, 0.0]
    } else {
        scale3(a, 1.0 / l)
    }
}

/// A random direction; `up` pushes it upward (0 = any direction).
fn dir_up(r: &mut Rng, up: f64) -> V3 {
    let d = r.dir();
    norm3([d[0], d[1] + up, d[2]])
}

// ---------------------------------------------------------------- bolts

/// A jagged line from `a` to `b` (`BoltParticle.jagged`).
fn jagged(a: V3, b: V3, rough: f64, depth: i32, r: &mut Rng) -> Vec<V3> {
    fn split(pts: &mut Vec<V3>, a: V3, b: V3, rough: f64, depth: i32, r: &mut Rng) {
        if depth <= 0 {
            return;
        }
        let len = len3(sub3(b, a));
        let mid = add3(
            scale3(add3(a, b), 0.5),
            [
                (r.f() - 0.5) * len * rough,
                (r.f() - 0.5) * len * rough,
                (r.f() - 0.5) * len * rough,
            ],
        );
        split(pts, a, mid, rough, depth - 1, r);
        pts.push(mid);
        split(pts, mid, b, rough, depth - 1, r);
    }
    let mut pts = vec![a];
    split(&mut pts, a, b, rough, depth, r);
    pts.push(b);
    pts
}

/// A bolt of lightning or an electric arc along `pts` (`BoltParticle`): a chain of glowing dots,
/// a bright core in a soft coloured glow, flickering as it fades (or glowing steadily).
#[allow(clippy::too_many_arguments)]
fn bolt(
    host: &mut dyn Host,
    pts: &[V3],
    width: f64,
    core: [f64; 3],
    glow: [f64; 3],
    life: i32,
    strength: f64,
    steady: bool,
    r: &mut Rng,
) {
    if pts.len() < 2 {
        return;
    }
    let flicker = r.below(1000) as f64;
    let dot = |host: &mut dyn Host, at: V3, size: f64, colour: [f64; 3], a: f64| {
        let fields = BTreeMap::from([
            ("lifetime".to_owned(), life.max(2) as f64),
            ("size".to_owned(), size),
            ("red".to_owned(), colour[0]),
            ("green".to_owned(), colour[1]),
            ("blue".to_owned(), colour[2]),
            ("alpha".to_owned(), if steady { 0.0 } else { a }),
            ("friction".to_owned(), 1.0),
        ]);
        let customs = BTreeMap::from([
            ("a0".to_owned(), a),
            ("seed".to_owned(), flicker),
            ("steady".to_owned(), if steady { 1.0 } else { 0.0 }),
        ]);
        add(
            host,
            "extremeexplosions2:fx_bolt",
            Seed { fields, customs },
            at,
            [0.0; 3],
        );
    };
    let glow_size = width * 2.2;
    let core_size = width * 0.75;
    for w in pts.windows(2) {
        let d = sub3(w[1], w[0]);
        let len = len3(d);
        let glow_steps = ((len / (glow_size * 0.9)).ceil() as i32).max(1);
        for k in 0..glow_steps {
            let at = add3(w[0], scale3(d, k as f64 / glow_steps as f64));
            dot(host, at, glow_size, glow, strength * 0.4);
        }
        let core_steps = ((len / (core_size * 0.9)).ceil() as i32).clamp(1, 48);
        for k in 0..core_steps {
            let at = add3(w[0], scale3(d, k as f64 / core_steps as f64));
            dot(host, at, core_size, core, strength);
        }
    }
    dot(host, pts[pts.len() - 1], core_size, core, strength);
}

/// A full lightning bolt from `a` to `b` with `branches` forks (`BoltParticle.strike`).
#[allow(clippy::too_many_arguments)]
fn strike(
    host: &mut dyn Host,
    a: V3,
    b: V3,
    width: f64,
    core: [f64; 3],
    glow: [f64; 3],
    life: i32,
    branches: i32,
    r: &mut Rng,
) {
    let len = len3(sub3(b, a));
    let depth = if len > 24.0 {
        6
    } else if len > 10.0 {
        5
    } else if len > 4.0 {
        4
    } else {
        3
    };
    let main = jagged(a, b, 0.45, depth, r);
    bolt(host, &main, width, core, glow, life, 1.0, false, r);
    for _ in 0..branches {
        if main.len() <= 4 {
            break;
        }
        let from = main[1 + r.below(main.len() as i32 - 3) as usize];
        let dir = norm3(sub3(b, a));
        let off = scale3([r.f() - 0.5, r.f() - 0.5, r.f() - 0.5], 1.6);
        let blen = len * (0.2 + r.f() * 0.3);
        let to = add3(from, scale3(norm3(add3(dir, off)), blen));
        let fork = jagged(from, to, 0.5, (depth - 2).max(2), r);
        let life = (life - 1 - r.below(2)).max(2);
        bolt(host, &fork, width * 0.55, core, glow, life, 0.8, false, r);
    }
}

// ---------------------------------------------------------------- the ground

/// Blocks a blast's dust and debris don't come from: air, fluids and things too thin to stand on.
fn solid(name: &str) -> bool {
    let path = name.rsplit(':').next().unwrap_or(name);
    if matches!(
        path,
        "air"
            | "cave_air"
            | "void_air"
            | "water"
            | "lava"
            | "snow"
            | "fire"
            | "soul_fire"
            | "light"
    ) {
        return false;
    }
    if path == "grass_block" {
        return true;
    }
    const THIN: [&str; 24] = [
        "grass",
        "fern",
        "flower",
        "sapling",
        "torch",
        "vine",
        "carpet",
        "rail",
        "button",
        "pressure_plate",
        "sign",
        "banner",
        "bush",
        "seagrass",
        "kelp",
        "wire",
        "lever",
        "tripwire",
        "tulip",
        "poppy",
        "dandelion",
        "orchid",
        "allium",
        "daisy",
    ];
    !THIN.iter().any(|t| path.contains(t))
}

/// The ground's colour for dust (`MapColor`, softened toward grey as the Java mod did).
fn dust_colour(name: &str) -> [f64; 3] {
    let path = name.rsplit(':').next().unwrap_or(name);
    let c = if path.contains("red_sand") {
        [0.75, 0.42, 0.2]
    } else if path.contains("sand") && !path.contains("soul") {
        [0.86, 0.81, 0.62]
    } else if path.contains("soul") {
        [0.32, 0.25, 0.2]
    } else if path.contains("snow") || path.contains("ice") {
        [0.95, 0.97, 1.0]
    } else if path.contains("nether") || path.contains("nylium") || path.contains("crimson") {
        [0.45, 0.16, 0.16]
    } else if path.contains("end_stone") {
        [0.86, 0.87, 0.6]
    } else if path.contains("terracotta") {
        [0.6, 0.4, 0.3]
    } else if path.contains("clay") {
        [0.62, 0.65, 0.72]
    } else if path.contains("deepslate") || path.contains("basalt") || path.contains("blackstone") {
        [0.3, 0.3, 0.32]
    } else if path.contains("gravel") {
        [0.55, 0.53, 0.52]
    } else if path.contains("grass")
        || path.contains("dirt")
        || path.contains("podzol")
        || path.contains("mud")
        || path.contains("farmland")
        || path.contains("mycelium")
    {
        [0.53, 0.38, 0.26]
    } else {
        [0.5, 0.5, 0.5]
    };
    [
        lerp(0.55, 0.6, c[0]),
        lerp(0.55, 0.6, c[1]),
        lerp(0.55, 0.6, c[2]),
    ]
}

/// The top of the ground below `from`, searching at most `down` blocks; the block found.
fn ground_below(host: &dyn Host, from: V3, down: i32) -> Option<(f64, String)> {
    let (x, y, z) = (
        from[0].floor() as i32,
        from[1].floor() as i32,
        from[2].floor() as i32,
    );
    (0..=down).find_map(|i| {
        let name = host.block([x, y - i, z]);
        solid(&name).then(|| ((y - i) as f64 + 1.0, name))
    })
}

// ---------------------------------------------------------------- the show

/// One explosion's show (`ExplosionDirector`), ticked for a second or so after the bang.
struct Show {
    x: f64,
    y: f64,
    z: f64,
    tg: u8,
    radius: f64,
    /// Size factor, 1 for a TNT sized blast.
    k: f64,
    /// Particle size radius (grows slower than the blast itself for huge blasts).
    sr: f64,
    /// Extra ticks the smoke column keeps going for big blasts.
    extra: i32,
    ground_y: f64,
    ground: Option<String>,
    dust: [f64; 3],
    underwater: bool,
    age: i32,
    lifetime: i32,
}

/// A chunk of rock flung out by a blast, trailing flames as it flies (`DebrisParticle`).
struct Burning {
    pos: V3,
    vel: V3,
    age: i32,
    life: i32,
    floor: f64,
}

/// An invisible emitter spiralling along a path, leaving a glowing ribbon of light (or flame)
/// behind it (`RibbonEmitter`).
struct Ribbon {
    cx: f64,
    cz: f64,
    y0: f64,
    r0: f64,
    r1: f64,
    angle0: f64,
    spin: f64,
    rise: f64,
    looping: f64,
    life: i32,
    size: f64,
    c0: [f64; 3],
    c1: [f64; 3],
    trail: i32,
    fire: bool,
    age: i32,
    last: Option<V3>,
}

impl Ribbon {
    fn at(&self, t: f64) -> V3 {
        let f = (t / self.life as f64).clamp(0.0, 1.0);
        let (h, rad) = if self.looping > 0.0 {
            let h = (t * self.rise) % self.looping;
            (h, self.r0 + (self.r1 - self.r0) * (h / self.looping))
        } else {
            (t * self.rise, self.r0 + (self.r1 - self.r0) * f)
        };
        let ang = self.angle0 + self.spin * t;
        [
            self.cx + ang.cos() * rad,
            self.y0 + h,
            self.cz + ang.sin() * rad,
        ]
    }
    fn alive(&self) -> bool {
        self.age < self.life
    }
    fn head(&self) -> V3 {
        self.at(self.age as f64)
    }
    fn tick(&mut self, host: &mut dyn Host, r: &mut Rng) {
        if self.age >= self.life {
            return;
        }
        self.age += 1;
        let life = self.life as f64;
        let fade = 1.0 - ((self.age as f64 - life * 0.7) / (life * 0.3)).max(0.0);
        let p = self.at(self.age as f64);
        let mut steps = 1;
        if let Some(l) = self.last {
            let d = len3(sub3(p, l));
            if self.looping > 0.0 && d > self.looping * 0.5 {
                self.last = None; // wrapped back to the bottom: no line across
            } else {
                steps = ((d / (self.size * 0.9)).ceil() as i32).clamp(1, 12);
            }
        }
        for i in 1..=steps {
            let k = i as f64 / steps as f64;
            let at = match self.last {
                Some(l) => add3(l, scale3(sub3(p, l), k)),
                None => p,
            };
            if self.fire {
                Fx::new(Kind::Fire, self.trail + r.below(6))
                    .size(self.size * 1.2, self.size * 0.4)
                    .color(self.c0, self.c1)
                    .alpha(0.9 * fade, 0.0, 0.3)
                    .motion(0.9, 0.0, 0.0)
                    .spin((r.f() - 0.5) * 0.2)
                    .spawn(host, at, [0.0, 0.03, 0.0], r);
            } else {
                Fx::new(Kind::Flash, self.trail)
                    .size(self.size, self.size * 0.25)
                    .color(self.c0, self.c1)
                    .alpha(0.95 * fade, 0.0, 0.15)
                    .spawn(host, at, [0.0; 3], r);
            }
        }
        if self.fire && r.below(3) == 0 {
            Fx::new(Kind::Smoke, 30 + r.below(20))
                .size(self.size * 1.5, self.size * 3.5)
                .color([0.2, 0.18, 0.17], [0.35, 0.35, 0.35])
                .alpha(0.55 * fade, 0.1, 0.4)
                .motion(0.95, 0.001, 0.0)
                .spawn(host, p, [0.0, 0.06, 0.0], r);
        }
        self.last = Some(p);
    }
}

/// Gens V to IX each have their own energy effect on top of the blast (`SignatureEffects`):
/// V a static burst of cyan arcs, VI a plasma helix, VII a thunderhead, VIII an implosion
/// vortex, IX a hellstorm fire twister.
struct Signature {
    tg: u8,
    c: V3,
    ground_y: f64,
    radius: f64,
    core: [f64; 3],
    glow: [f64; 3],
    ribbons: Vec<Ribbon>,
    orbs: Vec<V3>,
    age: i32,
    life: i32,
}

pub struct Client {
    shows: Vec<Show>,
    signatures: Vec<Signature>,
    burning: Vec<Burning>,
    trauma: f32,
    /// The screen flash: its peak, its age in ticks and whether it is gold (Gen X).
    flash: Option<(f32, i32, bool)>,
    rng: Rng,
    start: Instant,
}

impl Default for Client {
    fn default() -> Self {
        Self {
            shows: Vec::new(),
            signatures: Vec::new(),
            burning: Vec::new(),
            trauma: 0.0,
            flash: None,
            rng: Rng::default(),
            start: Instant::now(),
        }
    }
}

const FLASH_TICKS: i32 = 22;

fn camera(host: &dyn Host) -> Option<V3> {
    host.camera().map(|c| c.position)
}

impl Client {
    /// An explosion packet came: start its show on the next tick.
    pub fn explosion(&mut self, host: &mut dyn Host, center: V3, radius: f32) {
        let (tg, radius) = match gens::gen_of_radius(radius) {
            Some(g) => (g, Gen::of(g).effect_radius as f64),
            None => (1, radius as f64),
        };
        let radius = radius.clamp(1.0, 26.0);
        let at = [
            center[0].floor() as i32,
            center[1].floor() as i32,
            center[2].floor() as i32,
        ];
        let underwater = host.block(at) == "minecraft:water";
        let (ground_y, ground) = match ground_below(host, center, radius.ceil() as i32 + 2) {
            Some((y, name)) => (y, Some(name)),
            None => (center[1], None),
        };
        let dust = ground.as_deref().map_or([0.62, 0.56, 0.48], dust_colour);
        let extra = if tg >= 6 { (tg as i32 - 5) * 6 } else { 0 };
        self.shows.push(Show {
            x: center[0],
            y: center[1],
            z: center[2],
            tg,
            radius,
            k: (radius / 4.0).clamp(0.35, 6.5),
            sr: if radius <= 10.0 {
                radius
            } else {
                10.0 + (radius - 10.0) * 0.6
            },
            extra,
            ground_y,
            ground,
            dust,
            underwater,
            age: 0,
            lifetime: 26 + extra,
        });
        // The shake starts with the bang.
        if let Some(cam) = camera(host) {
            let d = len3(sub3(cam, center));
            let reach = radius * 7.0 + 10.0;
            let fall = (1.0 - d / reach).clamp(0.0, 1.0);
            let add = ((radius / 4.0).clamp(0.35, 1.6) * fall * fall * 1.1) as f32;
            self.trauma = (self.trauma + add).min(1.0);
            // Gens IX and X wash the screen out (gold for Gen X).
            if tg >= 9 && !underwater {
                let strength = (1.0 - d / (radius * 10.0)).clamp(0.0, 1.0) as f32;
                let peak = (if tg >= 10 { 0.92 } else { 0.7 }) * (0.35 + 0.65 * strength);
                let stronger = match self.flash {
                    Some((p, age, _)) => age >= FLASH_TICKS || peak >= p,
                    None => true,
                };
                if stronger {
                    self.flash = Some((peak, 0, tg >= 10));
                }
            }
        }
    }

    pub fn tick(&mut self, host: &mut dyn Host) {
        if self.trauma > 0.0 {
            self.trauma = (self.trauma - 0.05).max(0.0);
        }
        if let Some((_, age, _)) = &mut self.flash {
            *age += 1;
            if *age > FLASH_TICKS {
                self.flash = None;
            }
        }
        let mut shows = std::mem::take(&mut self.shows);
        for show in &mut shows {
            if show.age == 0 {
                if show.underwater {
                    self.burst_underwater(host, show);
                } else {
                    self.burst(host, show);
                }
            } else if !show.underwater {
                self.tick_show(host, show);
            }
            show.age += 1;
        }
        shows.retain(|s| !s.underwater && s.age <= s.lifetime);
        shows.append(&mut self.shows);
        self.shows = shows;

        let mut signatures = std::mem::take(&mut self.signatures);
        for s in &mut signatures {
            s.age += 1;
            for rb in &mut s.ribbons {
                rb.tick(host, &mut self.rng);
            }
            signature_tick(host, &mut self.rng, s);
        }
        signatures.retain(|s| s.age < s.life);
        self.signatures = signatures;

        // Burning debris trails flames and smoke as it flies.
        let r = &mut self.rng;
        for b in &mut self.burning {
            b.age += 1;
            b.vel[1] -= 0.04;
            b.pos = add3(b.pos, b.vel);
            b.vel = scale3(b.vel, 0.98);
            if b.pos[1] <= b.floor {
                b.age = b.life;
            }
            if (b.age as f64) < b.life as f64 * 0.6 {
                trail(host, r, b.pos);
            }
        }
        self.burning
            .retain(|b| (b.age as f64) < b.life as f64 * 0.6);
    }

    /// Adds the camera's shake: `trauma` squared, as the original.
    pub fn shake(&self, shake: &mut NativeShake) {
        if self.trauma <= 0.0 {
            return;
        }
        let power = self.trauma * self.trauma;
        let t = self.start.elapsed().as_secs_f64();
        let amp = 5.0 * power;
        shake.pitch += (t * 43.0 + 1.0).sin() as f32 * amp;
        shake.yaw += (t * 37.0 + 2.0).sin() as f32 * amp;
        shake.roll += (t * 51.0 + 4.0).sin() as f32 * amp * 0.8;
    }

    /// Washes the screen out white (gold for Gen X), fading fast.
    pub fn flash(&self, host: &mut dyn Host, batch: &mut HudBatch) {
        let Some((peak, age, gold)) = self.flash else {
            return;
        };
        let t = (age as f32 / FLASH_TICKS as f32).clamp(0.0, 1.0);
        let a = peak * (1.0 - t) * (1.0 - t);
        if a <= 0.01 {
            return;
        }
        let alpha = ((a * 255.0) as u32) << 24;
        let rgb = if gold { 0x00FF_F2D1 } else { 0x00FF_FFFF };
        let w = batch.width.max(1.0) * 2.0;
        let h = batch.height.max(1.0) * 2.0;
        host.fill(batch, [0.0, 0.0, w, h], alpha | rgb);
    }

    fn burst_underwater(&mut self, host: &mut dyn Host, s: &Show) {
        let r = &mut self.rng;
        let (x, y, z, rad, sr) = (s.x, s.y, s.z, s.radius, s.sr);
        let bubble = ParticleOptions::simple(ParticleType::Bubble);
        for _ in 0..(40.0 + 12.0 * rad) as i32 {
            let (dx, dy, dz) = (
                (r.f() - 0.5) * rad,
                (r.f() - 0.5) * rad,
                (r.f() - 0.5) * rad,
            );
            host.add_particle(
                &bubble,
                [x + dx, y + dy, z + dz],
                [dx * 0.15, 0.15 + r.f() * 0.2, dz * 0.15],
            );
        }
        Fx::new(Kind::Flash, 5)
            .size(sr * 0.8, sr * 2.0)
            .color([0.8, 0.9, 1.0], [0.4, 0.6, 0.9])
            .alpha(0.8, 0.0, 0.0)
            .spawn(host, [x, y, z], [0.0; 3], r);
        for _ in 0..(6.0 + rad) as i32 {
            let at = [
                x + (r.f() - 0.5) * rad * 0.6,
                y + (r.f() - 0.5) * rad * 0.6,
                z + (r.f() - 0.5) * rad * 0.6,
            ];
            Fx::new(Kind::Smoke, 40 + r.below(30))
                .size(sr * 0.25, sr * 0.7)
                .color([0.5, 0.55, 0.6], [0.35, 0.4, 0.45])
                .alpha(0.4, 0.1, 0.4)
                .motion(0.92, 0.002, 0.0)
                .spawn(host, at, [0.0, 0.02, 0.0], r);
        }
    }

    /// The bang: flash, fireball, sparks, flying debris, the dust ring, and for the bigger
    /// generations the shockwave, the wave of energy and their signature effect.
    fn burst(&mut self, host: &mut dyn Host, s: &Show) {
        let r = &mut self.rng;
        let (x, y, z, rad, k, sr) = (s.x, s.y, s.z, s.radius, s.k, s.sr);

        // 1. Blinding flash.
        Fx::new(Kind::Flash, 6)
            .size(sr * 0.9, sr * 3.0)
            .color([1.0, 0.95, 0.8], [1.0, 0.55, 0.2])
            .alpha(1.0, 0.0, 0.0)
            .ease(0.6)
            .spawn(host, [x, y + 0.3, z], [0.0; 3], r);

        // 2. Fireball.
        for _ in 0..(26.0 + 9.0 * rad).round() as i32 {
            let d = r.dir();
            let dist = rad * 0.5 * r.f().cbrt();
            let sp = (0.05 + r.f() * 0.16) * k;
            let s0 = sr * (0.22 + r.f() * 0.18);
            Fx::new(Kind::Fire, 14 + r.below(16))
                .size(s0, s0 * (1.6 + r.f() * 0.6))
                .color([1.0, 0.95, 0.65], [0.75, 0.12, 0.03])
                .alpha(0.95, 0.0, 0.3)
                .motion(0.88, 0.004, 0.0)
                .spin((r.f() - 0.5) * 0.12)
                .ease(0.5)
                .spawn(
                    host,
                    [
                        x + d[0] * dist,
                        y + d[1] * dist * 0.8 + 0.3,
                        z + d[2] * dist,
                    ],
                    [d[0] * sp, d[1] * sp * 0.8 + 0.04 * k, d[2] * sp],
                    r,
                );
        }

        // 3. Sparks.
        for _ in 0..(40.0 + 10.0 * rad).round() as i32 {
            let d = r.dir();
            let sp = (0.35 + r.f() * 0.8) * k.sqrt();
            Fx::new(Kind::Spark, 14 + r.below(22))
                .size(0.06 + r.f() * 0.06, 0.015)
                .color([1.0, 0.9, 0.5], [1.0, 0.35, 0.08])
                .alpha(1.0, 0.0, 0.45)
                .motion(0.95, 0.0, 0.032)
                .spawn(
                    host,
                    [x, y + 0.3, z],
                    [d[0] * sp, d[1] * sp + 0.12, d[2] * sp],
                    r,
                );
        }

        // 4. Flying debris, some of it burning.
        if s.ground.is_some() {
            for _ in 0..(14.0 + 5.0 * rad).round() as i32 {
                let ang = r.f() * TAU;
                let dist = r.f() * rad * 0.9;
                let (px, pz) = (x + ang.cos() * dist, z + ang.sin() * dist);
                let (py, colour) = match ground_below(host, [px, s.ground_y + 2.0, pz], 8) {
                    Some((gy, name)) => (gy, dust_colour(&name)),
                    None => (s.ground_y, s.dust),
                };
                let sp = (0.12 + r.f() * 0.4) * k.sqrt();
                let v = [
                    ang.cos() * sp,
                    (0.35 + r.f() * 0.6) * k.sqrt(),
                    ang.sin() * sp,
                ];
                let burning = r.f() < 0.3;
                let shade = if burning { 0.55 } else { 0.8 };
                let c = scale3(colour, shade);
                let size = 0.07 + r.f() * 0.09;
                let life = 40 + r.below(35);
                let at = [px, py + 0.2, pz];
                Fx::new(Kind::Debris, life)
                    .size(size, size)
                    .color(c, c)
                    .alpha(1.0, 0.0, 0.85)
                    .motion(0.98, 0.0, 0.04)
                    .spin((r.f() - 0.5) * 0.7)
                    .spawn(host, at, v, r);
                if burning && self.burning.len() < 400 {
                    self.burning.push(Burning {
                        pos: at,
                        vel: v,
                        age: 0,
                        life,
                        floor: py - 6.0,
                    });
                }
            }
        }
        let r = &mut self.rng;

        // 5. Ground dust ring.
        let dust = s.dust;
        let n = (22.0 + 6.0 * rad).round() as i32;
        for i in 0..n {
            let ang = (i as f64 + r.f()) / n as f64 * TAU;
            let sp = (0.2 + r.f() * 0.22) * k.sqrt();
            let start = rad * 0.35;
            let shade = 0.85 + r.f() * 0.3;
            Fx::new(Kind::Smoke, 22 + r.below(20))
                .size(sr * 0.16, sr * 0.5)
                .color(scale3(dust, shade), scale3(dust, 0.85))
                .alpha(0.6, 0.08, 0.4)
                .motion(0.9, 0.0, 0.0)
                .spin((r.f() - 0.5) * 0.05)
                .spawn(
                    host,
                    [
                        x + ang.cos() * start,
                        s.ground_y + 0.15,
                        z + ang.sin() * start,
                    ],
                    [ang.cos() * sp, 0.01 + r.f() * 0.04, ang.sin() * sp],
                    r,
                );
        }

        // Bigger generations add more on top.
        if s.tg >= 5 {
            // A fast low ring of dust racing out across the ground.
            let n = (40.0 + 3.0 * rad).round() as i32;
            let sp = 0.13 * rad;
            for i in 0..n {
                let ang = (i as f64 + r.f()) / n as f64 * TAU;
                let v = sp * (0.85 + r.f() * 0.3);
                let shade = 0.8 + r.f() * 0.15;
                Fx::new(Kind::Smoke, 18 + r.below(8))
                    .size(sr * 0.12, sr * 0.45)
                    .color(add3(scale3(dust, shade), [0.15; 3]), dust)
                    .alpha(0.55, 0.0, 0.3)
                    .motion(0.9, 0.0, 0.0)
                    .spin((r.f() - 0.5) * 0.06)
                    .spawn(
                        host,
                        [
                            x + ang.cos() * 1.5,
                            s.ground_y + 0.3 + r.f() * 0.6,
                            z + ang.sin() * 1.5,
                        ],
                        [ang.cos() * v, 0.0, ang.sin() * v],
                        r,
                    );
            }
        }
        if s.tg >= 10 {
            energy_wave(host, r, s, false);
        }
        if (5..=9).contains(&s.tg) {
            let sig = signature_start(host, r, s);
            self.signatures.push(sig);
        }
    }

    /// The show's later ticks: black smoke billowing out, the rising column and its mushroom
    /// cap, the condensation ring, Gen X's second wave and drifting embers.
    fn tick_show(&mut self, host: &mut dyn Host, s: &Show) {
        let r = &mut self.rng;
        let (x, y, z, rad, k, sr) = (s.x, s.y, s.z, s.radius, s.k, s.sr);
        let t = s.age;

        // Thick black smoke billowing out of the fireball.
        if t <= 10 + s.extra / 3 {
            for _ in 0..(3.0 + rad.min(14.0)).round() as i32 {
                let d = r.dir();
                let dist = rad * 0.55 * r.f().cbrt();
                let shade = 0.08 + r.f() * 0.1;
                Fx::new(Kind::Smoke, 65 + r.below(50))
                    .size(sr * 0.3, sr * (0.75 + r.f() * 0.35))
                    .color([shade; 3], [0.42, 0.41, 0.4])
                    .alpha(0.88, 0.08, 0.5)
                    .motion(0.93, 0.0012, 0.0)
                    .spin((r.f() - 0.5) * 0.04)
                    .spawn(
                        host,
                        [
                            x + d[0] * dist,
                            y + d[1] * dist * 0.7 + 0.4 + t as f64 * 0.08 * k,
                            z + d[2] * dist,
                        ],
                        [d[0] * 0.05 * k, (0.05 + r.f() * 0.07) * k, d[2] * 0.05 * k],
                        r,
                    );
            }
        }
        // The rising column and the mushroom cap.
        if t >= 2 && t <= 22 + s.extra && t % 2 == 0 {
            for _ in 0..(2.0 + rad * 0.4).round() as i32 {
                let shade = 0.15 + r.f() * 0.1;
                Fx::new(Kind::Smoke, 70 + r.below(40))
                    .size(sr * 0.22, sr * 0.6)
                    .color([shade; 3], [0.45; 3])
                    .alpha(0.75, 0.1, 0.55)
                    .motion(0.95, 0.0008, 0.0)
                    .spin((r.f() - 0.5) * 0.03)
                    .spawn(
                        host,
                        [
                            x + (r.f() - 0.5) * rad * 0.4,
                            y + 0.5 + t as f64 * 0.17 * k,
                            z + (r.f() - 0.5) * rad * 0.4,
                        ],
                        [0.0, 0.09 * k, 0.0],
                        r,
                    );
            }
        }
        if t == 14 + s.extra / 2 {
            let n = (10.0 + rad).round() as i32;
            let h = y + 0.5 + (22 + s.extra) as f64 * 0.17 * k * 0.8;
            for i in 0..n {
                let ang = (i as f64 + r.f()) / n as f64 * TAU;
                let sp = (0.05 + r.f() * 0.05) * k;
                let shade = 0.2 + r.f() * 0.1;
                Fx::new(Kind::Smoke, 70 + r.below(30))
                    .size(sr * 0.4, sr * 1.05)
                    .color([shade; 3], [0.5; 3])
                    .alpha(0.7, 0.1, 0.5)
                    .motion(0.93, 0.0, 0.0)
                    .spin((r.f() - 0.5) * 0.03)
                    .spawn(
                        host,
                        [x + ang.cos() * rad * 0.2, h, z + ang.sin() * rad * 0.2],
                        [ang.cos() * sp, 0.03 * k, ang.sin() * sp],
                        r,
                    );
            }
        }
        // Gen VII+: a white condensation ring blooming around the rising fireball.
        if s.tg >= 7 && t == 3 {
            let n = (30.0 + 2.0 * rad).round() as i32;
            let h = y + 0.5 + rad * 0.45;
            let sp = 0.06 * rad;
            for i in 0..n {
                let ang = (i as f64 + r.f()) / n as f64 * TAU;
                let v = sp * (0.9 + r.f() * 0.2);
                Fx::new(Kind::Smoke, 30 + r.below(14))
                    .size(sr * 0.2, sr * 0.55)
                    .color([0.97; 3], [0.85, 0.86, 0.88])
                    .alpha(0.6, 0.15, 0.35)
                    .motion(0.92, 0.0, 0.0)
                    .spin((r.f() - 0.5) * 0.04)
                    .spawn(
                        host,
                        [
                            x + ang.cos() * rad * 0.25,
                            h + (r.f() - 0.5) * 1.5,
                            z + ang.sin() * rad * 0.25,
                        ],
                        [ang.cos() * v, 0.01, ang.sin() * v],
                        r,
                    );
            }
        }
        if s.tg >= 10 && t == 8 {
            energy_wave(host, r, s, true);
        }
        // Drifting embers.
        if t <= 18 {
            for _ in 0..(2.0 + rad * 0.4).round() as i32 {
                let d = r.dir();
                Fx::new(Kind::Spark, 40 + r.below(40))
                    .size(0.05, 0.01)
                    .color([1.0, 0.65, 0.2], [0.6, 0.1, 0.0])
                    .alpha(0.9, 0.0, 0.5)
                    .motion(0.96, 0.0015, 0.0)
                    .spawn(
                        host,
                        [
                            x + d[0] * rad * 0.5,
                            y + 0.5 + d[1].abs() * rad * 0.4,
                            z + d[2] * rad * 0.5,
                        ],
                        [d[0] * 0.05, 0.05 + r.f() * 0.06, d[2] * 0.05],
                        r,
                    );
            }
        }
    }
}

/// A little flame and puff of smoke behind burning debris.
fn trail(host: &mut dyn Host, r: &mut Rng, at: V3) {
    Fx::new(Kind::Fire, 6 + r.below(4))
        .size(0.14, 0.03)
        .color([1.0, 0.8, 0.4], [0.8, 0.2, 0.05])
        .alpha(0.9, 0.0, 0.3)
        .motion(0.9, 0.0, 0.0)
        .spawn(host, at, [0.0, 0.01, 0.0], r);
    if r.f() < 0.35 {
        Fx::new(Kind::Smoke, 20 + r.below(12))
            .size(0.12, 0.4)
            .color([0.25; 3], [0.45; 3])
            .alpha(0.5, 0.1, 0.4)
            .motion(0.95, 0.001, 0.0)
            .spawn(host, at, [0.0, 0.02, 0.0], r);
    }
}

/// Gen X: a glowing sphere swells out of the blast while a ring of light races across the land,
/// keeping pace with the crater being torn out of the ground; an echo follows.
fn energy_wave(host: &mut dyn Host, r: &mut Rng, s: &Show, echo: bool) {
    let (x, y, z, sr) = (s.x, s.y, s.z, s.sr);
    let bright = if echo { 0.6 } else { 1.0 };
    if !echo {
        Fx::new(Kind::Flash, 24)
            .size(1.0, sr * 2.4)
            .color([1.0; 3], [0.45, 0.75, 1.0])
            .alpha(0.85, 0.0, 0.25)
            .ease(0.45)
            .spawn(host, [x, y + 0.5, z], [0.0; 3], r);
        for i in 0..14 {
            Fx::new(Kind::Flash, 18 + r.below(6))
                .size(2.5, 1.0)
                .color([1.0, 0.95, 0.7], [1.0, 0.6, 0.2])
                .alpha(0.9, 0.0, 0.3)
                .motion(0.97, 0.0, 0.0)
                .spawn(
                    host,
                    [x, y + 0.5 + i as f64 * 0.6, z],
                    [0.0, 0.9 + i as f64 * 0.12, 0.0],
                    r,
                );
        }
    }
    let n = if echo { 110 } else { 170 };
    let sp = s.radius / 22.0;
    for layer in 0..2 {
        for i in 0..n {
            let ang = (i as f64 + r.f()) / n as f64 * TAU;
            let py = y + 0.4 + layer as f64 * 1.6 + r.f() * 0.8;
            let (s0, s1) = if layer == 0 { (3.2, 5.0) } else { (2.2, 3.4) };
            Fx::new(Kind::Flash, 40 + r.below(6))
                .size(s0, s1)
                .color(
                    scale3([0.75, 0.95, 1.0], bright),
                    scale3([0.55, 0.3, 1.0], bright),
                )
                .alpha(0.9 * bright, 0.0, 0.45)
                .motion(1.0, 0.0, 0.0)
                .spawn(
                    host,
                    [x + ang.cos(), py, z + ang.sin()],
                    [ang.cos() * sp, 0.0, ang.sin() * sp],
                    r,
                );
        }
    }
    for _ in 0..(if echo { 40 } else { 90 }) {
        let ang = r.f() * TAU;
        let v = sp * (0.7 + r.f() * 0.6);
        Fx::new(Kind::Spark, 30 + r.below(20))
            .size(0.12, 0.04)
            .color([0.9, 1.0, 1.0], [0.5, 0.4, 1.0])
            .alpha(1.0, 0.0, 0.5)
            .motion(0.99, 0.0, 0.02)
            .spawn(
                host,
                [x, y + 0.5 + r.f() * 2.0, z],
                [ang.cos() * v, 0.15 + r.f() * 0.3, ang.sin() * v],
                r,
            );
    }
}

// ---------------------------------------------------------------- signature effects

const CORE: [[f64; 3]; 5] = [
    [0.85, 1.0, 1.0],  // V cyan
    [0.85, 0.9, 1.0],  // VI blue
    [0.95, 0.85, 1.0], // VII purple
    [1.0, 0.85, 0.97], // VIII magenta
    [1.0, 0.85, 0.6],  // IX red-hot
];
const GLOW: [[f64; 3]; 5] = [
    [0.2, 0.85, 1.0],
    [0.25, 0.4, 1.0],
    [0.6, 0.25, 1.0],
    [1.0, 0.2, 0.75],
    [1.0, 0.15, 0.05],
];

fn sound(host: &mut dyn Host, sound: &str, at: V3, volume: f32, pitch: f32) {
    host.play_local_sound(sound, at, volume, pitch, 0);
}

/// The top of the ground at `x`, `z` near the blast (its own height where that isn't found).
fn ground_at(host: &dyn Host, s: &Signature, x: f64, z: f64) -> V3 {
    let top = s.ground_y + s.radius * 1.5;
    let reach = (s.radius * 3.0).ceil() as i32;
    let y = ground_below(host, [x, top, z], reach).map_or(s.ground_y, |(y, _)| y);
    [x, y, z]
}

fn signature_start(host: &mut dyn Host, r: &mut Rng, show: &Show) -> Signature {
    let i = (show.tg - 5) as usize;
    let mut s = Signature {
        tg: show.tg,
        c: [show.x, show.y + 0.5, show.z],
        ground_y: show.ground_y,
        radius: show.radius,
        core: CORE[i],
        glow: GLOW[i],
        ribbons: Vec::new(),
        orbs: Vec::new(),
        age: 0,
        life: match show.tg {
            5 => 26,
            6 => 50,
            7 => 70,
            8 => 80,
            _ => 90,
        },
    };
    let (x, y, z, rad) = (show.x, show.y, show.z, show.radius);
    let ribbon =
        |cx, y0, cz, r0, r1, angle0, spin, rise, looping, life, size, c0, c1, trail, fire| Ribbon {
            cx,
            cz,
            y0,
            r0,
            r1,
            angle0,
            spin,
            rise,
            looping,
            life,
            size,
            c0,
            c1,
            trail,
            fire,
            age: 0,
            last: None,
        };
    match show.tg {
        5 => {
            // Arcs bursting out of the fireball, mostly upward and outward.
            for _ in 0..10 {
                let to = add3(s.c, scale3(dir_up(r, 0.15), rad * (0.6 + r.f() * 0.5)));
                strike(host, s.c, to, 0.14, s.core, s.glow, 5 + r.below(3), 2, r);
            }
            sound(
                host,
                "minecraft:entity.lightning_bolt.impact",
                s.c,
                2.0,
                1.6,
            );
        }
        6 => {
            // Three plasma ribbons climbing round the smoke column.
            for i in 0..3 {
                s.ribbons.push(ribbon(
                    x,
                    y + 0.5,
                    z,
                    rad * 0.25,
                    rad * 0.6,
                    i as f64 * (TAU / 3.0),
                    0.32,
                    rad * 1.9 / 45.0,
                    0.0,
                    45,
                    0.45,
                    [0.7, 0.85, 1.0],
                    [0.35, 0.15, 1.0],
                    12,
                    false,
                ));
            }
            for _ in 0..6 {
                let to = add3(s.c, scale3(dir_up(r, 0.0), rad * (0.5 + r.f() * 0.4)));
                strike(host, s.c, to, 0.16, s.core, s.glow, 6, 2, r);
            }
            sound(host, "minecraft:block.beacon.activate", s.c, 3.0, 0.6);
        }
        7 => lightning_strike(host, r, &s, true),
        8 => {
            // Energy sucked in from all around in a whirlpool.
            for i in 0..6 {
                s.ribbons.push(ribbon(
                    x,
                    show.ground_y + 0.6 + (i % 2) as f64 * 1.5,
                    z,
                    rad * 1.6,
                    0.5,
                    i as f64 * (TAU / 6.0),
                    0.2,
                    0.0,
                    0.0,
                    18,
                    0.5,
                    [1.0, 0.75, 0.95],
                    [0.9, 0.1, 0.7],
                    10,
                    false,
                ));
            }
            sound(host, "minecraft:block.beacon.deactivate", s.c, 4.0, 0.5);
        }
        _ => {
            // A fire twister: four flame ribbons wound into a cone.
            for i in 0..4 {
                s.ribbons.push(ribbon(
                    x,
                    show.ground_y - rad * 0.4,
                    z,
                    1.5,
                    rad * 0.35,
                    i as f64 * (TAU / 4.0),
                    0.55,
                    1.4,
                    rad * 2.0,
                    80,
                    0.55,
                    [1.0, 0.85, 0.4],
                    [0.9, 0.15, 0.02],
                    8,
                    true,
                ));
            }
            sound(host, "minecraft:entity.blaze.shoot", s.c, 4.0, 0.5);
        }
    }
    s
}

fn signature_tick(host: &mut dyn Host, r: &mut Rng, s: &mut Signature) {
    let t = s.age;
    let (x, y, z, rad) = (s.c[0], s.c[1] - 0.5, s.c[2], s.radius);
    match s.tg {
        5 => {
            // Static crackling across the ground round the blast.
            if t >= 2 && r.f() < 0.55 {
                ground_arc(
                    host,
                    s,
                    rad * (0.4 + r.f() * 0.9),
                    2.0 + r.f() * 3.0,
                    0.08,
                    r,
                );
            }
            if t == 6 || t == 12 {
                let to = add3(s.c, scale3(dir_up(r, 0.3), rad * 0.7));
                let from = add3(s.c, [0.0, rad * 0.3, 0.0]);
                strike(host, from, to, 0.12, s.core, s.glow, 4, 1, r);
            }
        }
        6 => {
            // Arcs jumping off the climbing ribbons.
            if t % 4 == 0 && t < 44 {
                let heads: Vec<V3> = s
                    .ribbons
                    .iter()
                    .filter(|rb| rb.alive())
                    .map(Ribbon::head)
                    .collect();
                for from in heads {
                    if r.f() > 0.6 {
                        continue;
                    }
                    let to = add3(from, scale3(dir_up(r, 0.0), 2.0 + r.f() * rad * 0.35));
                    strike(host, from, to, 0.09, s.core, s.glow, 4, 1, r);
                }
            }
            // A ring of blue sparks shed from the top as it finishes.
            if t == 40 {
                let top = y + 0.5 + rad * 1.7;
                for _ in 0..50 {
                    let ang = r.f() * TAU;
                    let v = 0.25 + r.f() * 0.25;
                    Fx::new(Kind::Spark, 25 + r.below(15))
                        .size(0.15, 0.04)
                        .color([0.7, 0.85, 1.0], [0.3, 0.2, 1.0])
                        .alpha(1.0, 0.0, 0.5)
                        .motion(0.95, 0.0, 0.02)
                        .spawn(
                            host,
                            [x, top, z],
                            [ang.cos() * v, (r.f() - 0.3) * 0.2, ang.sin() * v],
                            r,
                        );
                }
            }
        }
        7 => {
            // The storm: lightning out of the cloud every few ticks, flickering inside it.
            if t < 62 && r.f() < 0.24 {
                lightning_strike(host, r, s, false);
            }
            if t % 3 == 0 && t < 66 {
                let cloud = y + 0.5 + rad * 1.3;
                let p = [
                    x + (r.f() - 0.5) * rad,
                    cloud + (r.f() - 0.5) * rad * 0.4,
                    z + (r.f() - 0.5) * rad,
                ];
                Fx::new(Kind::Flash, 3)
                    .size(rad * 0.35, rad * 0.2)
                    .color([0.85, 0.75, 1.0], s.glow)
                    .alpha(0.5, 0.0, 0.0)
                    .spawn(host, p, [0.0; 3], r);
                if r.below(2) == 0 {
                    let d = dir_up(r, 0.0);
                    let q = add3(p, scale3([d[0], d[1] * 0.3, d[2]], rad * 0.4));
                    strike(host, p, q, 0.12, s.core, s.glow, 3, 1, r);
                }
            }
        }
        8 => {
            // The whirlpool collapses at tick 18 and bursts back out.
            if t == 18 {
                implosion_burst(host, r, s);
            }
            if t > 18 && t < 74 && t % 3 == 0 && s.orbs.len() >= 2 && r.f() < 0.8 {
                let a = s.orbs[r.below(s.orbs.len() as i32) as usize];
                let b = s.orbs[r.below(s.orbs.len() as i32) as usize];
                if a != b && len3(sub3(a, b)) < rad * 0.9 {
                    strike(host, a, b, 0.1, s.core, s.glow, 4, 0, r);
                } else {
                    let g = ground_at(
                        host,
                        s,
                        a[0] + (r.f() - 0.5) * 4.0,
                        a[2] + (r.f() - 0.5) * 4.0,
                    );
                    strike(host, a, g, 0.1, s.core, s.glow, 4, 1, r);
                }
            }
        }
        _ => {
            // Red lightning lashing out of the twister.
            if t > 4 && t < 80 && r.f() < 0.18 {
                let from = [
                    x + (r.f() - 0.5) * 3.0,
                    y + r.f() * rad * 1.6,
                    z + (r.f() - 0.5) * 3.0,
                ];
                let ang = r.f() * TAU;
                let d = rad * (0.8 + r.f() * 0.8);
                let to = ground_at(host, s, x + ang.cos() * d, z + ang.sin() * d);
                strike(host, from, to, 0.2, s.core, s.glow, 5, 2, r);
                if r.below(3) == 0 {
                    let pitch = 0.6 + r.f() as f32 * 0.3;
                    sound(
                        host,
                        "minecraft:entity.lightning_bolt.impact",
                        s.c,
                        2.0,
                        pitch,
                    );
                }
            }
            // Once the crater is torn out, the ground round the rim splits with glowing cracks.
            if t == 28 {
                magma_cracks(host, r, s);
            }
            // Embers raining down over everything.
            if t < 75 {
                for _ in 0..5 {
                    let ang = r.f() * TAU;
                    let d = r.f().sqrt() * rad * 1.7;
                    Fx::new(Kind::Fire, 50 + r.below(30))
                        .size(0.12, 0.05)
                        .color([1.0, 0.75, 0.3], [0.8, 0.15, 0.0])
                        .alpha(1.0, 0.0, 0.6)
                        .motion(0.98, 0.0, 0.006)
                        .spawn(
                            host,
                            [
                                x + ang.cos() * d,
                                y + rad * (1.2 + r.f() * 0.6),
                                z + ang.sin() * d,
                            ],
                            [(r.f() - 0.5) * 0.05, -0.1, (r.f() - 0.5) * 0.05],
                            r,
                        );
                }
            }
            if t == 20 || t == 45 {
                sound(host, "minecraft:item.firecharge.use", s.c, 4.0, 0.5);
            }
        }
    }
}

/// Gen V: a short arc hopping between two points on the ground.
fn ground_arc(host: &mut dyn Host, s: &Signature, dist: f64, span: f64, width: f64, r: &mut Rng) {
    let (x, z) = (s.c[0], s.c[2]);
    let ang = r.f() * TAU;
    let (ax, az) = (x + ang.cos() * dist, z + ang.sin() * dist);
    let ang2 = r.f() * TAU;
    let a = add3(ground_at(host, s, ax, az), [0.0, 0.2, 0.0]);
    let b = add3(
        ground_at(host, s, ax + ang2.cos() * span, az + ang2.sin() * span),
        [0.0, 0.2, 0.0],
    );
    let mid = add3(scale3(add3(a, b), 0.5), [0.0, span * 0.35, 0.0]);
    let mut pts = jagged(a, mid, 0.4, 3, r);
    pts.extend_from_slice(&jagged(mid, b, 0.4, 3, r)[1..]);
    bolt(
        host,
        &pts,
        width,
        s.core,
        s.glow,
        3 + r.below(3),
        1.0,
        false,
        r,
    );
    Fx::new(Kind::Flash, 3)
        .size(0.6, 0.2)
        .color(s.core, s.glow)
        .alpha(0.8, 0.0, 0.0)
        .spawn(host, b, [0.0; 3], r);
    if r.below(4) == 0 {
        let pitch = 1.8 + r.f() as f32 * 0.2;
        sound(
            host,
            "minecraft:entity.lightning_bolt.impact",
            b,
            0.6,
            pitch,
        );
    }
}

/// Gen VII: one big lightning strike from the cloud to the ground.
fn lightning_strike(host: &mut dyn Host, r: &mut Rng, s: &Signature, first: bool) {
    let (x, y, z, rad) = (s.c[0], s.c[1] - 0.5, s.c[2], s.radius);
    let cloud = y + 0.5 + rad * 1.35;
    let ang = r.f() * TAU;
    let d = rad * if first { 0.6 } else { 0.3 + r.f() * 1.2 };
    let from = [
        x + (r.f() - 0.5) * rad * 0.6,
        cloud,
        z + (r.f() - 0.5) * rad * 0.6,
    ];
    let to = ground_at(host, s, x + ang.cos() * d, z + ang.sin() * d);
    let width = if first { 0.35 } else { 0.25 };
    strike(
        host,
        from,
        to,
        width,
        s.core,
        s.glow,
        7 + r.below(3),
        3 + r.below(2),
        r,
    );
    // A flash where it hits, and a splash of sparks.
    Fx::new(Kind::Flash, 5)
        .size(2.5, 1.0)
        .color([1.0; 3], s.glow)
        .alpha(1.0, 0.0, 0.0)
        .spawn(host, add3(to, [0.0, 0.3, 0.0]), [0.0; 3], r);
    for _ in 0..14 {
        let dv = scale3(dir_up(r, 0.2), 0.2 + r.f() * 0.25);
        Fx::new(Kind::Spark, 12 + r.below(12))
            .size(0.1, 0.03)
            .color(s.core, s.glow)
            .alpha(1.0, 0.0, 0.4)
            .motion(0.95, 0.0, 0.035)
            .spawn(
                host,
                add3(to, [0.0, 0.2, 0.0]),
                [dv[0], dv[1].abs() + 0.1, dv[2]],
                r,
            );
    }
    // Light up the cloud it came from.
    Fx::new(Kind::Flash, 4)
        .size(rad * 0.6, rad * 0.3)
        .color([0.95, 0.9, 1.0], s.glow)
        .alpha(0.6, 0.0, 0.0)
        .spawn(host, from, [0.0; 3], r);
    if first {
        sound(
            host,
            "minecraft:entity.lightning_bolt.thunder",
            s.c,
            6.0,
            0.8,
        );
    } else if r.below(2) == 0 {
        let pitch = 0.7 + r.f() as f32 * 0.4;
        sound(
            host,
            "minecraft:entity.lightning_bolt.impact",
            to,
            2.5,
            pitch,
        );
    }
}

/// Gen VIII: the whirlpool bursts back out.
fn implosion_burst(host: &mut dyn Host, r: &mut Rng, s: &mut Signature) {
    let (c, rad) = (s.c, s.radius);
    Fx::new(Kind::Flash, 14)
        .size(1.0, rad * 1.4)
        .color([1.0, 0.9, 1.0], [0.9, 0.15, 0.7])
        .alpha(0.9, 0.0, 0.2)
        .ease(0.4)
        .spawn(host, c, [0.0; 3], r);
    for _ in 0..12 {
        let to = add3(c, scale3(dir_up(r, 0.05), rad * (0.7 + r.f() * 0.6)));
        strike(host, c, to, 0.2, s.core, s.glow, 6 + r.below(3), 2, r);
    }
    // A magenta ring rushing outward.
    let n = 90;
    let sp = rad / 16.0;
    for i in 0..n {
        let ang = (i as f64 + r.f()) / n as f64 * TAU;
        Fx::new(Kind::Flash, 26)
            .size(2.0, 3.2)
            .color([1.0, 0.6, 0.95], [0.6, 0.1, 0.9])
            .alpha(0.85, 0.0, 0.4)
            .motion(1.0, 0.0, 0.0)
            .spawn(
                host,
                [c[0] + ang.cos(), s.ground_y + 0.6, c[2] + ang.sin()],
                [ang.cos() * sp, 0.0, ang.sin() * sp],
                r,
            );
    }
    // Energy orbs left hanging in the air.
    for _ in 0..9 {
        let ang = r.f() * TAU;
        let d = rad * (0.3 + r.f() * 0.9);
        let p = [
            c[0] + ang.cos() * d,
            c[1] + 2.0 + r.f() * rad * 0.8,
            c[2] + ang.sin() * d,
        ];
        s.orbs.push(p);
        Fx::new(Kind::Flash, 60 + r.below(10))
            .size(0.4, 1.1)
            .color([1.0, 0.85, 1.0], [0.85, 0.2, 0.75])
            .alpha(0.9, 0.1, 0.7)
            .motion(0.98, 0.0, 0.0)
            .ease(0.8)
            .spawn(host, p, [0.0, 0.004, 0.0], r);
    }
    sound(host, "minecraft:entity.generic.explode", c, 6.0, 0.6);
    sound(host, "minecraft:entity.lightning_bolt.impact", c, 4.0, 0.8);
}

/// Gen IX: glowing cracks splitting the ground outward from the crater rim.
fn magma_cracks(host: &mut dyn Host, r: &mut Rng, s: &Signature) {
    let (x, z, rad) = (s.c[0], s.c[2], s.radius);
    let n = 14;
    for i in 0..n {
        let ang = (i as f64 + r.f() * 0.6) / n as f64 * TAU;
        let (start, end) = (rad, rad * (1.4 + r.f() * 0.5));
        let mut pts = Vec::new();
        let mut wobble = 0.0;
        let mut d = start;
        while d <= end {
            wobble += (r.f() - 0.5) * 0.25;
            let a = ang + wobble / d.max(4.0) * 3.0;
            pts.push(add3(
                ground_at(host, s, x + a.cos() * d, z + a.sin() * d),
                [0.0, 0.06, 0.0],
            ));
            d += 0.8;
        }
        bolt(
            host,
            &pts,
            0.22,
            [1.0, 0.75, 0.3],
            [1.0, 0.2, 0.0],
            70 + r.below(20),
            0.9,
            true,
            r,
        );
    }
}
