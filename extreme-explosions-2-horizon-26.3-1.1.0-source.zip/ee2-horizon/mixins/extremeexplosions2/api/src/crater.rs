//! Carves the crater for TNT Gen VI and up (`Craters`). The shape is a ragged-edged bowl going
//! `down` blocks below the TNT, topped by a dome of destruction `up` blocks above it, `width`
//! blocks across. The carving spreads outward from the middle over about a second, keeping pace
//! with the shockwave the players see, so the server never removes tens of thousands of blocks
//! in one go.
use crate::Rng;
use crate::gens::{self, Gen};
use horizon_client::mod_api::*;

/// Most blocks of a crater dropped as items, by generation: Gen VI only, as the original's
/// default, so the big ones don't bury the world in items.
const DROPS_UP_TO_GEN: u8 = 6;

pub struct Crater {
    pub dimension: String,
    pub finished: bool,
    c: [i32; 3],
    tg: Gen,
    reach: i32,
    size: i32,
    /// Per column: the lowest and highest y offset removed (lo > hi: nothing).
    lo: Vec<i32>,
    hi: Vec<i32>,
    /// The ragged outer edge's columns (patchy damage).
    rim: Vec<bool>,
    /// The columns, nearest first.
    order: Vec<usize>,
    dist: Vec<f32>,
    drop_chance: f64,
    speed: f32,
    next: usize,
    ticks: i32,
    rng: Rng,
}

/// Blocks a blast never breaks: unbreakable ones, and fluids (left standing, as the original).
fn unbreakable(name: &str) -> bool {
    matches!(
        name,
        "minecraft:bedrock"
            | "minecraft:barrier"
            | "minecraft:command_block"
            | "minecraft:chain_command_block"
            | "minecraft:repeating_command_block"
            | "minecraft:structure_block"
            | "minecraft:structure_void"
            | "minecraft:jigsaw"
            | "minecraft:end_portal"
            | "minecraft:end_portal_frame"
            | "minecraft:end_gateway"
            | "minecraft:reinforced_deepslate"
            | "minecraft:light"
            | "minecraft:moving_piston"
            | "minecraft:test_block"
            | "minecraft:test_instance_block"
            | "minecraft:water"
            | "minecraft:lava"
            | "minecraft:bubble_column"
            | "minecraft:kelp"
            | "minecraft:kelp_plant"
            | "minecraft:seagrass"
            | "minecraft:tall_seagrass"
    )
}

/// Blocks with a blast resistance of 1200 or more: they survive up to Gen VIII.
fn blast_proof(name: &str) -> bool {
    matches!(
        name,
        "minecraft:obsidian"
            | "minecraft:crying_obsidian"
            | "minecraft:respawn_anchor"
            | "minecraft:ancient_debris"
            | "minecraft:netherite_block"
            | "minecraft:enchanting_table"
            | "minecraft:ender_chest"
            | "minecraft:anvil"
            | "minecraft:chipped_anvil"
            | "minecraft:damaged_anvil"
    )
}

fn is_air(name: &str) -> bool {
    matches!(
        name,
        "minecraft:air" | "minecraft:cave_air" | "minecraft:void_air"
    )
}

impl Crater {
    pub fn new(dimension: String, center: [f64; 3], tg: Gen, seed: u64) -> Self {
        let mut rng = Rng(seed | 1);
        let r = tg.crater_radius() as f64;
        let reach = (r * 1.18).ceil() as i32 + 1;
        let size = reach * 2 + 1;
        let n = (size * size) as usize;
        let mut lo = vec![1; n];
        let mut hi = vec![0; n];
        let mut rim = vec![false; n];
        let mut dist = vec![0.0f32; n];
        let mut cols = Vec::new();
        // A lumpy outline, so the crater is not a perfect circle.
        let (p1, p2, p3) = (
            rng.f() * std::f64::consts::TAU,
            rng.f() * std::f64::consts::TAU,
            rng.f() * std::f64::consts::TAU,
        );
        for dx in -reach..=reach {
            for dz in -reach..=reach {
                let i = ((dx + reach) * size + (dz + reach)) as usize;
                let d = ((dx * dx + dz * dz) as f64).sqrt();
                let ang = (dz as f64).atan2(dx as f64);
                let edge = r
                    * (1.0
                        + 0.07 * (3.0 * ang + p1).sin()
                        + 0.05 * (5.0 * ang + p2).sin()
                        + 0.03 * (9.0 * ang + p3).sin());
                let h = d / edge;
                dist[i] = d as f32;
                if h <= 1.0 {
                    // Bowl below, dome above.
                    let depth = tg.down as f64 * (1.0 - h * h).sqrt() + (rng.f() - 0.5) * 1.2;
                    let height = tg.up as f64 * (1.0 - h * h * h * h).max(0.0).sqrt()
                        + (rng.f() - 0.5) * 1.2;
                    lo[i] = -(depth.max(0.0).round() as i32);
                    hi[i] = height.max(1.0).round() as i32;
                    cols.push(i);
                } else if h <= 1.15 {
                    // Ragged rim: patchy damage around the ground level.
                    let fade = 1.0 - (h - 1.0) / 0.15;
                    if rng.f() < 0.35 + 0.5 * fade {
                        lo[i] = -((fade * 2.0).round() as i32);
                        hi[i] = (1.0 + fade * tg.up as f64 * 0.35).round() as i32;
                        rim[i] = true;
                        cols.push(i);
                    }
                }
            }
        }
        cols.sort_by(|&a, &b| dist[a].total_cmp(&dist[b]));
        Self {
            dimension,
            finished: false,
            c: [
                center[0].floor() as i32,
                center[1].floor() as i32,
                center[2].floor() as i32,
            ],
            tg,
            reach,
            size,
            lo,
            hi,
            rim,
            order: cols,
            dist,
            drop_chance: 1.0 / r.max(1.0),
            // Gen X: 25 blocks in about 25 ticks.
            speed: (r as f32 / 25.0).max(0.8),
            next: 0,
            ticks: 0,
            rng,
        }
    }

    fn inside(&self, dx: i32, dy: i32, dz: i32) -> bool {
        if dx < -self.reach || dx > self.reach || dz < -self.reach || dz > self.reach {
            return false;
        }
        let i = ((dx + self.reach) * self.size + (dz + self.reach)) as usize;
        dy >= self.lo[i] && dy <= self.hi[i]
    }

    /// Carves the columns the wave has reached; returns the budget left for other craters.
    /// TNT it meets is put in `lit` (its position and generation, 1 for plain TNT).
    pub fn step(
        &mut self,
        host: &mut dyn Host,
        mut budget: i32,
        air: Option<BlockStateId>,
        lit: &mut Vec<([i32; 3], u8)>,
    ) -> i32 {
        let Some(air) = air else {
            self.finished = true;
            return budget;
        };
        self.ticks += 1;
        let wave = self.ticks as f32 * self.speed + 1.0;
        let drops = self.tg.number <= DROPS_UP_TO_GEN;
        // Inside the crater, blocks go in bulk with no neighbour updates; on its surface one by
        // one, so sand falls, water flows and torches pop.
        let mut edit = NativeBlockEdit {
            palette: vec!["minecraft:air".to_owned()],
            ..Default::default()
        };
        while self.next < self.order.len() && budget > 0 && self.dist[self.order[self.next]] <= wave
        {
            let i = self.order[self.next];
            self.next += 1;
            let dx = i as i32 / self.size - self.reach;
            let dz = i as i32 % self.size - self.reach;
            let (x, z) = (self.c[0] + dx, self.c[2] + dz);
            let mut run: Option<(i32, u32)> = None; // bottom y and height of the bulk run
            for dy in (self.lo[i]..=self.hi[i]).rev() {
                let y = self.c[1] + dy;
                if !(-64..=319).contains(&y) || (self.rim[i] && self.rng.f() < 0.4) {
                    flush(&mut edit, &mut run, x, z);
                    continue;
                }
                let pos = [x, y, z];
                let name = host.block(pos);
                if is_air(&name) || unbreakable(&name) {
                    flush(&mut edit, &mut run, x, z);
                    continue;
                }
                if self.tg.number < 9 && blast_proof(&name) {
                    flush(&mut edit, &mut run, x, z);
                    continue;
                }
                if host.block_property(pos, "waterlogged").as_deref() == Some("true") {
                    flush(&mut edit, &mut run, x, z);
                    continue;
                }
                budget -= 1;
                // Chain reaction: light TNT instead of deleting it.
                let tnt = if name == "minecraft:tnt" {
                    Some(1)
                } else {
                    gens::gen_of_block(&name)
                };
                if let Some(g) = tnt {
                    flush(&mut edit, &mut run, x, z);
                    host.set_block(&self.dimension, pos, air, 3);
                    lit.push((pos, g));
                    continue;
                }
                if drops && self.rng.f() < self.drop_chance {
                    flush(&mut edit, &mut run, x, z);
                    host.destroy_block(pos, None, false);
                    continue;
                }
                let surface = self.rim[i]
                    || !self.inside(dx + 1, dy, dz)
                    || !self.inside(dx - 1, dy, dz)
                    || !self.inside(dx, dy + 1, dz)
                    || !self.inside(dx, dy - 1, dz)
                    || !self.inside(dx, dy, dz + 1)
                    || !self.inside(dx, dy, dz - 1);
                if surface {
                    flush(&mut edit, &mut run, x, z);
                    host.set_block(&self.dimension, pos, air, 3);
                } else {
                    // Going down the column: the run grows downward.
                    run = Some(match run {
                        Some((_, h)) => (y, h + 1),
                        None => (y, 1),
                    });
                }
            }
            flush(&mut edit, &mut run, x, z);
        }
        if !edit.runs.is_empty() {
            let _ = host.edit_blocks(&self.dimension, &edit);
        }
        if self.next >= self.order.len() {
            self.finished = true;
        }
        budget
    }
}

/// Ends the column's bulk run, if one is open.
fn flush(edit: &mut NativeBlockEdit, run: &mut Option<(i32, u32)>, x: i32, z: i32) {
    if let Some((y, height)) = run.take() {
        edit.runs.push(NativeBlockRun {
            x,
            z,
            y,
            height,
            surface: None,
            block: 0,
            only: None,
        });
    }
}
