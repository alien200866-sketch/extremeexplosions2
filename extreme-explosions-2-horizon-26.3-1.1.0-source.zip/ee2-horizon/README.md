# Extreme Explosions 2 for Horizon

By AndyMFA. (C) Many Fun Adventures.

A native trait mod for Horizon (Minecraft 26.3 in Rust), pinned to Horizon Nightly 2026-11-13
(9f42064) and Horizon Mixins 5a64af9.

- `horizon-mixin.toml`: the bundle (mod id, Horizon pin, the `api` package).
- `api/src/lib.rs`: the hooks; `gens.rs` the ten generations; `server.rs` lighting, the swap to a
  primed TNT of the right generation, chain reactions, damage and booms; `crater.rs` the craters
  of Gens VI-X; `client.rs` the explosion show, camera shake and screen flash.

The textures, models, recipes, loot, language and particle types are the content beside it, in
the same `.hmod` (`horizon-mod.toml`, `assets/`, `data/`).
